import { ReactNode } from "react";

interface StatusCardDetail {
  label: string;
  value: number | string;
}

interface StatusCardProps {
  title: string;
  value: number;
  icon: ReactNode;
  color: "primary" | "success" | "warning" | "gray" | string;
  details: StatusCardDetail[];
}

export default function StatusCard({ title, value, icon, color, details }: StatusCardProps) {
  const getBackgroundColor = () => {
    switch (color) {
      case "primary":
        return "bg-primary text-white";
      case "success":
        return "bg-green-500 text-white";
      case "warning":
        return "bg-amber-500 text-white";
      case "gray":
        return "bg-gray-700 text-white";
      default:
        return `bg-${color} text-white`;
    }
  };

  return (
    <div className={`rounded-md shadow-md overflow-hidden ${getBackgroundColor()}`}>
      <div className="p-3 sm:p-4">
        <div className="flex justify-between items-center">
          <div className="text-xl sm:text-2xl">{icon}</div>
          <span className="text-3xl sm:text-4xl font-bold">{value}</span>
        </div>
        <div className="mt-1 sm:mt-2 text-sm sm:text-base">{title}</div>
      </div>
      <div className="bg-white bg-opacity-20 p-2 flex flex-wrap justify-between text-xs sm:text-sm">
        {details.map((detail, index) => (
          <span key={index} className="mr-2 mb-1 sm:mb-0">
            {detail.label}: {detail.value}
          </span>
        ))}
      </div>
    </div>
  );
}
