import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, XCircle, Info, CreditCard, Tag } from "lucide-react";
import { Input } from "../ui/input";
import { Label } from "../ui/label";

export default function BillingSettings() {
  const [activeTab, setActiveTab] = useState("subscriptions");
  
  // Check URL parameters for active tab
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    if (tabParam && ['subscriptions', 'invoices', 'payment-methods'].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, []);
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Pengaturan Billing</h2>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="subscriptions">Paket Layanan</TabsTrigger>
          <TabsTrigger value="invoices">Invoice</TabsTrigger>
          <TabsTrigger value="payment-methods">Metode Pembayaran</TabsTrigger>
        </TabsList>
        
        {/* Tab Paket Layanan */}
        <TabsContent value="subscriptions">
          <Card>
            <CardHeader>
              <CardTitle>Paket Langganan</CardTitle>
              <CardDescription>
                Kelola paket langganan berdasarkan durasi waktu.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {/* Paket 1 Bulan */}
                <Card className="border-2 hover:border-primary transition-colors">
                  <CardHeader className="bg-muted/50 pb-2">
                    <CardTitle className="text-lg">1 Bulan</CardTitle>
                    <CardDescription>Paket Bulanan Standar</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="text-3xl font-bold mb-2">Rp 250.000</div>
                    <div className="text-gray-500 mb-4">per bulan</div>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Full dukungan teknis
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Tanpa kontrak jangka panjang
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Fleksibilitas maksimal
                      </li>
                    </ul>
                    <Button className="w-full">Pilih Paket</Button>
                  </CardContent>
                </Card>
                
                {/* Paket 6 Bulan */}
                <Card className="border-2 border-primary">
                  <div className="bg-primary text-white text-center py-1 text-xs font-medium">
                    TERPOPULER
                  </div>
                  <CardHeader className="bg-muted/50 pb-2">
                    <CardTitle className="text-lg">6 Bulan</CardTitle>
                    <CardDescription>Paket Tengah Tahunan</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="text-3xl font-bold mb-2">Rp 1.350.000</div>
                    <div className="text-gray-500 mb-4">
                      <span className="line-through mr-2">Rp 1.500.000</span>
                      <Badge variant="outline" className="text-green-600">Hemat 10%</Badge>
                    </div>
                    <div className="text-sm text-gray-500 mb-4">Rp 225.000 / bulan</div>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Full dukungan teknis
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Hemat 10% dari harga bulanan
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Bantuan prioritas 24/7
                      </li>
                    </ul>
                    <Button className="w-full">Pilih Paket</Button>
                  </CardContent>
                </Card>
                
                {/* Paket 1 Tahun */}
                <Card className="border-2 hover:border-primary transition-colors">
                  <CardHeader className="bg-muted/50 pb-2">
                    <CardTitle className="text-lg">1 Tahun</CardTitle>
                    <CardDescription>Paket Tahunan</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="text-3xl font-bold mb-2">Rp 2.400.000</div>
                    <div className="text-gray-500 mb-4">
                      <span className="line-through mr-2">Rp 3.000.000</span>
                      <Badge variant="outline" className="text-green-600">Hemat 20%</Badge>
                    </div>
                    <div className="text-sm text-gray-500 mb-4">Rp 200.000 / bulan</div>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Full dukungan teknis
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Hemat 20% dari harga bulanan
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" /> Konsultasi teknis premium
                      </li>
                    </ul>
                    <Button className="w-full">Pilih Paket</Button>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mt-8">
                <h3 className="font-medium text-lg mb-4">Daftar Paket Langganan</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Nama Paket</TableHead>
                      <TableHead>Durasi</TableHead>
                      <TableHead>Harga Normal</TableHead>
                      <TableHead>Harga Diskon</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>1</TableCell>
                      <TableCell>Paket Bulanan</TableCell>
                      <TableCell>1 Bulan</TableCell>
                      <TableCell>Rp 250.000</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell><Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge></TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>2</TableCell>
                      <TableCell>Paket Tengah Tahunan</TableCell>
                      <TableCell>6 Bulan</TableCell>
                      <TableCell>Rp 1.500.000</TableCell>
                      <TableCell>Rp 1.350.000</TableCell>
                      <TableCell><Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge></TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>3</TableCell>
                      <TableCell>Paket Tahunan</TableCell>
                      <TableCell>1 Tahun</TableCell>
                      <TableCell>Rp 3.000.000</TableCell>
                      <TableCell>Rp 2.400.000</TableCell>
                      <TableCell><Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge></TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">Edit</Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Invoice */}
        <TabsContent value="invoices">
          <Card>
            <CardHeader>
              <CardTitle>Invoice</CardTitle>
              <CardDescription>
                Kelola dan lihat status invoice pelanggan.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <div className="flex gap-2 items-center">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Filter Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Status</SelectItem>
                      <SelectItem value="paid">Lunas</SelectItem>
                      <SelectItem value="pending">Menunggu</SelectItem>
                      <SelectItem value="overdue">Terlambat</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Select defaultValue="30">
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Periode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 Hari Terakhir</SelectItem>
                      <SelectItem value="30">30 Hari Terakhir</SelectItem>
                      <SelectItem value="90">3 Bulan Terakhir</SelectItem>
                      <SelectItem value="180">6 Bulan Terakhir</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button>
                  <Info className="mr-2 h-4 w-4" />
                  Buat Invoice
                </Button>
              </div>
              
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>No. Invoice</TableHead>
                    <TableHead>Pelanggan</TableHead>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Jatuh Tempo</TableHead>
                    <TableHead>Jumlah</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>INV-2023-001</TableCell>
                    <TableCell>PT. Cahaya Network</TableCell>
                    <TableCell>01 Mar 2023</TableCell>
                    <TableCell>15 Mar 2023</TableCell>
                    <TableCell>Rp 2.400.000</TableCell>
                    <TableCell>
                      <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                        <CheckCircle className="mr-1 h-3 w-3" /> Lunas
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">Lihat</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>INV-2023-002</TableCell>
                    <TableCell>PT. Maju Jaya</TableCell>
                    <TableCell>05 Mar 2023</TableCell>
                    <TableCell>19 Mar 2023</TableCell>
                    <TableCell>Rp 1.350.000</TableCell>
                    <TableCell>
                      <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                        <Clock className="mr-1 h-3 w-3" /> Menunggu
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">Lihat</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>INV-2023-003</TableCell>
                    <TableCell>CV. Abadi Sentosa</TableCell>
                    <TableCell>10 Feb 2023</TableCell>
                    <TableCell>24 Feb 2023</TableCell>
                    <TableCell>Rp 250.000</TableCell>
                    <TableCell>
                      <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
                        <XCircle className="mr-1 h-3 w-3" /> Terlambat
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">Lihat</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Metode Pembayaran */}
        <TabsContent value="payment-methods">
          <Card>
            <CardHeader>
              <CardTitle>Metode Pembayaran</CardTitle>
              <CardDescription>
                Kelola metode pembayaran yang tersedia untuk pelanggan.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {/* Metode Pembayaran Aktif */}
                <div>
                  <h3 className="font-medium text-lg mb-4">Metode Pembayaran Aktif</h3>
                  <div className="space-y-4">
                    {/* Bank Transfer */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="bg-blue-100 p-2 rounded-md">
                              <CreditCard className="h-5 w-5 text-blue-600" />
                            </div>
                            <div>
                              <div className="font-medium">Bank Transfer</div>
                              <div className="text-sm text-gray-500">BCA, Mandiri, BNI, BRI</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {/* QRIS */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="bg-green-100 p-2 rounded-md">
                              <CreditCard className="h-5 w-5 text-green-600" />
                            </div>
                            <div>
                              <div className="font-medium">QRIS</div>
                              <div className="text-sm text-gray-500">Semua e-wallet & mobile banking</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {/* Virtual Account */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="bg-purple-100 p-2 rounded-md">
                              <Tag className="h-5 w-5 text-purple-600" />
                            </div>
                            <div>
                              <div className="font-medium">Virtual Account</div>
                              <div className="text-sm text-gray-500">BCA, Mandiri, BNI, BRI</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {/* OVO */}
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="bg-purple-100 p-2 rounded-md">
                              <CreditCard className="h-5 w-5 text-purple-600" />
                            </div>
                            <div>
                              <div className="font-medium">OVO</div>
                              <div className="text-sm text-gray-500">Pembayaran digital</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-600">Aktif</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                {/* Tambah Metode Pembayaran Baru */}
                <div>
                  <h3 className="font-medium text-lg mb-4">Tambah Metode Pembayaran</h3>
                  <Card>
                    <CardContent className="p-6">
                      <form className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="paymentName">Nama Metode Pembayaran</Label>
                          <Input id="paymentName" placeholder="contoh: GoPay" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="paymentType">Tipe Pembayaran</Label>
                          <Select>
                            <SelectTrigger id="paymentType">
                              <SelectValue placeholder="Pilih tipe pembayaran" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="bank">Bank Transfer</SelectItem>
                              <SelectItem value="ewallet">E-Wallet</SelectItem>
                              <SelectItem value="va">Virtual Account</SelectItem>
                              <SelectItem value="card">Kartu Kredit/Debit</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="accountNumber">Nomor Rekening/Akun</Label>
                          <Input id="accountNumber" placeholder="contoh: 12345678" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="accountName">Atas Nama</Label>
                          <Input id="accountName" placeholder="Nama pemilik akun" />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="instructions">Instruksi Pembayaran</Label>
                          <Input id="instructions" placeholder="Petunjuk untuk pelanggan" />
                        </div>
                        
                        <Button className="w-full">Simpan Metode Pembayaran</Button>
                      </form>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}