import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { AlertCircle, RefreshCw, Save, Shield, Globe, Server, Clock, Bell, Upload, Download, Database, Key } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const generalSettingsSchema = z.object({
  systemName: z.string().min(1, { message: "Nama sistem wajib diisi" }),
  companyLogo: z.string().optional(),
  timezone: z.string(),
  dateFormat: z.string(),
  language: z.string(),
});

const securitySettingsSchema = z.object({
  passwordMinLength: z.number().min(6),
  passwordRequireSpecial: z.boolean(),
  passwordRequireNumbers: z.boolean(),
  sessionTimeout: z.number().min(5),
  enable2FA: z.boolean(),
  storeUserLogs: z.boolean(),
});

const backupSettingsSchema = z.object({
  enableAutoBackup: z.boolean(),
  backupFrequency: z.string(),
  backupRetention: z.number().min(1),
  backupLocation: z.string().optional(),
});

const notificationSettingsSchema = z.object({
  smtpServer: z.string().optional(),
  smtpPort: z.number().optional(),
  smtpUsername: z.string().optional(),
  smtpPassword: z.string().optional(),
  emailFrom: z.string().email().optional(),
  notifyOnDeviceOffline: z.boolean(),
  notifyOnCriticalErrors: z.boolean(),
  telegramEnabled: z.boolean(),
  telegramToken: z.string().optional(),
});

const licenseSettingsSchema = z.object({
  licenseKey: z.string().optional(),
  licenseType: z.string(),
  expiryDate: z.string().optional(),
  autoUpdateEnabled: z.boolean(),
});

const integrationSettingsSchema = z.object({
  apiEnabled: z.boolean(),
  apiKey: z.string().optional(),
  allowWebhooks: z.boolean(),
  ssoEnabled: z.boolean(),
  ssoProvider: z.string().optional(),
});

type GeneralSettingsValues = z.infer<typeof generalSettingsSchema>;
type SecuritySettingsValues = z.infer<typeof securitySettingsSchema>;
type BackupSettingsValues = z.infer<typeof backupSettingsSchema>;
type NotificationSettingsValues = z.infer<typeof notificationSettingsSchema>;
type LicenseSettingsValues = z.infer<typeof licenseSettingsSchema>;
type IntegrationSettingsValues = z.infer<typeof integrationSettingsSchema>;

export default function SystemSettings() {
  const [activeTab, setActiveTab] = useState("general");
  const { toast } = useToast();
  
  // General Settings Form
  const generalForm = useForm<GeneralSettingsValues>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: {
      systemName: "WebOLT",
      timezone: "Asia/Jakarta",
      dateFormat: "DD/MM/YYYY",
      language: "id",
    },
  });

  // Security Settings Form
  const securityForm = useForm<SecuritySettingsValues>({
    resolver: zodResolver(securitySettingsSchema),
    defaultValues: {
      passwordMinLength: 8,
      passwordRequireSpecial: true,
      passwordRequireNumbers: true,
      sessionTimeout: 30,
      enable2FA: false,
      storeUserLogs: true,
    },
  });

  // Backup Settings Form
  const backupForm = useForm<BackupSettingsValues>({
    resolver: zodResolver(backupSettingsSchema),
    defaultValues: {
      enableAutoBackup: true,
      backupFrequency: "daily",
      backupRetention: 7,
      backupLocation: "/backups",
    },
  });

  // Notification Settings Form
  const notificationForm = useForm<NotificationSettingsValues>({
    resolver: zodResolver(notificationSettingsSchema),
    defaultValues: {
      notifyOnDeviceOffline: true,
      notifyOnCriticalErrors: true,
      telegramEnabled: false,
    },
  });

  // License Settings Form
  const licenseForm = useForm<LicenseSettingsValues>({
    resolver: zodResolver(licenseSettingsSchema),
    defaultValues: {
      licenseType: "professional",
      autoUpdateEnabled: true,
    },
  });

  // Integration Settings Form
  const integrationForm = useForm<IntegrationSettingsValues>({
    resolver: zodResolver(integrationSettingsSchema),
    defaultValues: {
      apiEnabled: false,
      allowWebhooks: false,
      ssoEnabled: false,
    },
  });

  const onGeneralSubmit = (data: GeneralSettingsValues) => {
    console.log(data);
    toast({
      title: "Pengaturan umum disimpan",
      description: "Perubahan pengaturan umum telah berhasil disimpan.",
    });
  };

  const onSecuritySubmit = (data: SecuritySettingsValues) => {
    console.log(data);
    toast({
      title: "Pengaturan keamanan disimpan",
      description: "Perubahan pengaturan keamanan telah berhasil disimpan.",
    });
  };

  const onBackupSubmit = (data: BackupSettingsValues) => {
    console.log(data);
    toast({
      title: "Pengaturan backup disimpan",
      description: "Perubahan pengaturan backup telah berhasil disimpan.",
    });
  };

  const onNotificationSubmit = (data: NotificationSettingsValues) => {
    console.log(data);
    toast({
      title: "Pengaturan notifikasi disimpan",
      description: "Perubahan pengaturan notifikasi telah berhasil disimpan.",
    });
  };

  const onLicenseSubmit = (data: LicenseSettingsValues) => {
    console.log(data);
    toast({
      title: "Pengaturan lisensi disimpan",
      description: "Perubahan pengaturan lisensi telah berhasil disimpan.",
    });
  };

  const onIntegrationSubmit = (data: IntegrationSettingsValues) => {
    console.log(data);
    toast({
      title: "Pengaturan integrasi disimpan",
      description: "Perubahan pengaturan integrasi telah berhasil disimpan.",
    });
  };

  const handleBackupNow = () => {
    toast({
      title: "Backup dimulai",
      description: "Proses backup manual telah dimulai. Anda akan diberitahu ketika selesai.",
    });
    // Simulasi proses backup
    setTimeout(() => {
      toast({
        title: "Backup selesai",
        description: "Backup database telah berhasil diselesaikan.",
      });
    }, 3000);
  };

  const handleRestoreBackup = () => {
    toast({
      title: "Konfirmasi diperlukan",
      description: "Fitur restore dari backup akan segera tersedia.",
      variant: "default",
    });
  };

  const handleCheckUpdate = () => {
    toast({
      title: "Memeriksa pembaruan",
      description: "Sedang memeriksa pembaruan sistem...",
    });
    // Simulasi pemeriksaan update
    setTimeout(() => {
      toast({
        title: "Sistem sudah terbaru",
        description: "Anda menggunakan versi terbaru WebOLT v1.0.0",
      });
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Pengaturan Sistem</h2>
        <Badge variant="outline" className="bg-blue-50 text-blue-600">Versi 1.0.0</Badge>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4 grid grid-cols-3 md:grid-cols-6 h-auto">
          <TabsTrigger value="general" className="flex gap-2 items-center py-2">
            <Globe className="h-4 w-4" />
            <span className="hidden md:inline">Umum</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex gap-2 items-center py-2">
            <Shield className="h-4 w-4" />
            <span className="hidden md:inline">Keamanan</span>
          </TabsTrigger>
          <TabsTrigger value="backup" className="flex gap-2 items-center py-2">
            <Database className="h-4 w-4" />
            <span className="hidden md:inline">Backup</span>
          </TabsTrigger>
          <TabsTrigger value="notification" className="flex gap-2 items-center py-2">
            <Bell className="h-4 w-4" />
            <span className="hidden md:inline">Notifikasi</span>
          </TabsTrigger>
          <TabsTrigger value="license" className="flex gap-2 items-center py-2">
            <Key className="h-4 w-4" />
            <span className="hidden md:inline">Lisensi</span>
          </TabsTrigger>
          <TabsTrigger value="integration" className="flex gap-2 items-center py-2">
            <Server className="h-4 w-4" />
            <span className="hidden md:inline">Integrasi</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Tab Pengaturan Umum */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Pengaturan Umum</CardTitle>
              <CardDescription>
                Konfigurasi pengaturan dasar aplikasi WebOLT anda.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...generalForm}>
                <form onSubmit={generalForm.handleSubmit(onGeneralSubmit)} className="space-y-6">
                  <FormField
                    control={generalForm.control}
                    name="systemName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nama Sistem</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormDescription>
                          Nama yang akan ditampilkan di judul halaman dan header.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={generalForm.control}
                    name="companyLogo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Logo Perusahaan</FormLabel>
                        <FormControl>
                          <div className="flex items-center gap-2">
                            <Input 
                              type="file" 
                              className="w-full" 
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  field.onChange(URL.createObjectURL(file));
                                }
                              }}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Unggah logo perusahaan anda (format JPG/PNG, maks 2MB).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={generalForm.control}
                      name="timezone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Zona Waktu</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih zona waktu" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Asia/Jakarta">Asia/Jakarta (WIB)</SelectItem>
                              <SelectItem value="Asia/Makassar">Asia/Makassar (WITA)</SelectItem>
                              <SelectItem value="Asia/Jayapura">Asia/Jayapura (WIT)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Zona waktu untuk menampilkan waktu dalam aplikasi.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={generalForm.control}
                      name="dateFormat"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Format Tanggal</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih format tanggal" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                              <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                              <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Format tanggal yang digunakan dalam aplikasi.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={generalForm.control}
                    name="language"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bahasa</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih bahasa" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="id">Bahasa Indonesia</SelectItem>
                            <SelectItem value="en">English</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Bahasa yang digunakan dalam antarmuka aplikasi.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button type="submit" className="w-full sm:w-auto">
                    <Save className="mr-2 h-4 w-4" />
                    Simpan Pengaturan
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Keamanan */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Pengaturan Keamanan</CardTitle>
              <CardDescription>
                Konfigurasi pengaturan keamanan dan akses aplikasi.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...securityForm}>
                <form onSubmit={securityForm.handleSubmit(onSecuritySubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={securityForm.control}
                      name="passwordMinLength"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Panjang Minimal Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="6" 
                              max="32" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription>
                            Jumlah minimal karakter untuk password pengguna.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={securityForm.control}
                      name="sessionTimeout"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Waktu Timeout Sesi (menit)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="5" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription>
                            Durasi tidak aktif sebelum pengguna otomatis keluar.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={securityForm.control}
                      name="passwordRequireSpecial"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>Memerlukan Karakter Khusus</FormLabel>
                            <FormDescription>
                              Password harus memiliki minimal 1 karakter khusus (mis. @, #, $)
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={securityForm.control}
                      name="passwordRequireNumbers"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>Memerlukan Angka</FormLabel>
                            <FormDescription>
                              Password harus memiliki minimal 1 angka
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={securityForm.control}
                      name="enable2FA"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>Autentikasi Dua Faktor (2FA)</FormLabel>
                            <FormDescription>
                              Aktifkan autentikasi dua faktor untuk login admin
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={securityForm.control}
                      name="storeUserLogs"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>Menyimpan Log Aktivitas Pengguna</FormLabel>
                            <FormDescription>
                              Catat semua login dan aktivitas pengguna dalam sistem
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full sm:w-auto">
                    <Save className="mr-2 h-4 w-4" />
                    Simpan Pengaturan Keamanan
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Backup & Restore */}
        <TabsContent value="backup">
          <Card>
            <CardHeader>
              <CardTitle>Backup & Restore</CardTitle>
              <CardDescription>
                Konfigurasi pengaturan cadangan dan pemulihan data.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-6">
                <Button variant="outline" onClick={handleBackupNow}>
                  <Download className="mr-2 h-4 w-4" />
                  Backup Sekarang
                </Button>
                <Button variant="outline" onClick={handleRestoreBackup}>
                  <Upload className="mr-2 h-4 w-4" />
                  Restore dari Backup
                </Button>
              </div>
              
              <Form {...backupForm}>
                <form onSubmit={backupForm.handleSubmit(onBackupSubmit)} className="space-y-6">
                  <FormField
                    control={backupForm.control}
                    name="enableAutoBackup"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel>Backup Otomatis</FormLabel>
                          <FormDescription>
                            Aktifkan backup database secara otomatis
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={backupForm.control}
                      name="backupFrequency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Frekuensi Backup</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                            disabled={!backupForm.watch("enableAutoBackup")}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih frekuensi" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="hourly">Setiap Jam</SelectItem>
                              <SelectItem value="daily">Harian</SelectItem>
                              <SelectItem value="weekly">Mingguan</SelectItem>
                              <SelectItem value="monthly">Bulanan</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Seberapa sering backup otomatis dilakukan.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={backupForm.control}
                      name="backupRetention"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Retensi Backup (hari)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1" 
                              {...field} 
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                              disabled={!backupForm.watch("enableAutoBackup")}
                            />
                          </FormControl>
                          <FormDescription>
                            Berapa lama backup akan disimpan sebelum dihapus otomatis.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={backupForm.control}
                    name="backupLocation"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lokasi Backup</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            disabled={!backupForm.watch("enableAutoBackup")}
                          />
                        </FormControl>
                        <FormDescription>
                          Direktori penyimpanan file backup (path absolut).
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full sm:w-auto"
                    disabled={!backupForm.watch("enableAutoBackup")}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Simpan Pengaturan Backup
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Notifikasi */}
        <TabsContent value="notification">
          <Card>
            <CardHeader>
              <CardTitle>Pengaturan Notifikasi</CardTitle>
              <CardDescription>
                Konfigurasi notifikasi email dan integrasi dengan layanan pesan.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...notificationForm}>
                <form onSubmit={notificationForm.handleSubmit(onNotificationSubmit)} className="space-y-6">
                  <div className="border rounded-lg p-4 mb-6">
                    <h3 className="text-lg font-medium mb-4">Pengaturan Email</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={notificationForm.control}
                        name="smtpServer"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Server</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="smtp.example.com" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={notificationForm.control}
                        name="smtpPort"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Port</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                {...field}
                                placeholder="587"
                                onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={notificationForm.control}
                        name="smtpUsername"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Username</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="username@example.com" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={notificationForm.control}
                        name="smtpPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>SMTP Password</FormLabel>
                            <FormControl>
                              <Input type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={notificationForm.control}
                        name="emailFrom"
                        render={({ field }) => (
                          <FormItem className="md:col-span-2">
                            <FormLabel>Email Pengirim</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="noreply@webolt.com" />
                            </FormControl>
                            <FormDescription>
                              Alamat email yang akan muncul sebagai pengirim notifikasi.
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-4 mb-6">
                    <h3 className="text-lg font-medium mb-4">Jenis Notifikasi</h3>
                    <div className="space-y-4">
                      <FormField
                        control={notificationForm.control}
                        name="notifyOnDeviceOffline"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Perangkat Offline</FormLabel>
                              <FormDescription>
                                Kirim notifikasi ketika perangkat terdeteksi offline
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={notificationForm.control}
                        name="notifyOnCriticalErrors"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>Error Kritis</FormLabel>
                              <FormDescription>
                                Kirim notifikasi untuk error kritis dalam sistem
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-4 mb-6">
                    <h3 className="text-lg font-medium mb-4">Integrasi Telegram</h3>
                    <FormField
                      control={notificationForm.control}
                      name="telegramEnabled"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 mb-4">
                          <div className="space-y-0.5">
                            <FormLabel>Aktifkan Notifikasi Telegram</FormLabel>
                            <FormDescription>
                              Kirim notifikasi melalui bot Telegram
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={notificationForm.control}
                      name="telegramToken"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Token Bot Telegram</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              disabled={!notificationForm.watch("telegramEnabled")} 
                            />
                          </FormControl>
                          <FormDescription>
                            Token API dari bot Telegram anda.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full sm:w-auto">
                    <Save className="mr-2 h-4 w-4" />
                    Simpan Pengaturan Notifikasi
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Lisensi & Pembaruan */}
        <TabsContent value="license">
          <Card>
            <CardHeader>
              <CardTitle>Lisensi & Pembaruan</CardTitle>
              <CardDescription>
                Kelola lisensi dan pengaturan pembaruan sistem.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5 mr-3" />
                  <div>
                    <h4 className="font-medium text-blue-700">Informasi Lisensi</h4>
                    <p className="text-blue-600 text-sm mt-1">
                      Anda menggunakan WebOLT versi 1.0.0 dengan lisensi Professional.
                      Masa aktif lisensi hingga 31 Desember 2025.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-4 mb-6">
                <Button variant="outline" onClick={handleCheckUpdate}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Periksa Pembaruan
                </Button>
              </div>
              
              <Form {...licenseForm}>
                <form onSubmit={licenseForm.handleSubmit(onLicenseSubmit)} className="space-y-6">
                  <FormField
                    control={licenseForm.control}
                    name="licenseKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Kunci Lisensi</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="XXXX-XXXX-XXXX-XXXX" />
                        </FormControl>
                        <FormDescription>
                          Masukkan kunci lisensi anda untuk aktivasi atau pembaruan.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={licenseForm.control}
                    name="licenseType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipe Lisensi</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih tipe lisensi" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="basic">Basic</SelectItem>
                            <SelectItem value="professional">Professional</SelectItem>
                            <SelectItem value="enterprise">Enterprise</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Tipe lisensi menentukan fitur yang tersedia.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={licenseForm.control}
                    name="autoUpdateEnabled"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel>Pembaruan Otomatis</FormLabel>
                          <FormDescription>
                            Secara otomatis unduh dan terapkan pembaruan ketika tersedia
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <Button type="submit" className="w-full sm:w-auto">
                    <Save className="mr-2 h-4 w-4" />
                    Simpan Pengaturan Lisensi
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Tab Integrasi */}
        <TabsContent value="integration">
          <Card>
            <CardHeader>
              <CardTitle>Pengaturan Integrasi</CardTitle>
              <CardDescription>
                Konfigurasi integrasi dengan layanan dan sistem eksternal.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...integrationForm}>
                <form onSubmit={integrationForm.handleSubmit(onIntegrationSubmit)} className="space-y-6">
                  <div className="border rounded-lg p-4 mb-6">
                    <h3 className="text-lg font-medium mb-4">API</h3>
                    <FormField
                      control={integrationForm.control}
                      name="apiEnabled"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 mb-4">
                          <div className="space-y-0.5">
                            <FormLabel>Aktifkan API</FormLabel>
                            <FormDescription>
                              Izinkan akses ke sistem melalui API
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={integrationForm.control}
                      name="apiKey"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Kunci API</FormLabel>
                          <div className="flex gap-2">
                            <FormControl className="flex-1">
                              <Input 
                                {...field} 
                                readOnly 
                                value={field.value || "API belum dibuat"}
                                disabled={!integrationForm.watch("apiEnabled")}
                              />
                            </FormControl>
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => {
                                const key = Math.random().toString(36).substring(2, 15) + 
                                           Math.random().toString(36).substring(2, 15);
                                field.onChange(key);
                              }}
                              disabled={!integrationForm.watch("apiEnabled")}
                            >
                              Generate
                            </Button>
                          </div>
                          <FormDescription>
                            Kunci akses untuk API anda.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="border rounded-lg p-4 mb-6">
                    <h3 className="text-lg font-medium mb-4">Webhooks</h3>
                    <FormField
                      control={integrationForm.control}
                      name="allowWebhooks"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Aktifkan Webhooks</FormLabel>
                            <FormDescription>
                              Kirim notifikasi peristiwa ke URL eksternal
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="border rounded-lg p-4 mb-6">
                    <h3 className="text-lg font-medium mb-4">Single Sign-On (SSO)</h3>
                    <FormField
                      control={integrationForm.control}
                      name="ssoEnabled"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 mb-4">
                          <div className="space-y-0.5">
                            <FormLabel>Aktifkan SSO</FormLabel>
                            <FormDescription>
                              Izinkan login melalui penyedia identitas eksternal
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={integrationForm.control}
                      name="ssoProvider"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Penyedia SSO</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                            disabled={!integrationForm.watch("ssoEnabled")}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Pilih penyedia SSO" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="google">Google</SelectItem>
                              <SelectItem value="microsoft">Microsoft</SelectItem>
                              <SelectItem value="keycloak">Keycloak</SelectItem>
                              <SelectItem value="custom">Custom OIDC</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Penyedia identitas untuk autentikasi SSO.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button type="submit" className="w-full sm:w-auto">
                    <Save className="mr-2 h-4 w-4" />
                    Simpan Pengaturan Integrasi
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}