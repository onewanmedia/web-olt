import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Edit } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Sample data - in a real app this would come from an API
const sampleOltTypes = [
  {
    id: 1,
    name: 'ZTE',
    ip: '91.192.81.36',
    telnetPort: '2323',
    iptv: 'no',
    hardwareVersion: 'ZTE-C320',
    softwareVersion: '2.x'
  }
];

export default function OltTypesSettings() {
  const { toast } = useToast();
  const [oltTypes, setOltTypes] = useState(sampleOltTypes);

  const handleAdd = () => {
    toast({
      title: "Add OLT Type",
      description: "This functionality would open a form to add a new OLT type."
    });
  };

  const handleEdit = (id: number) => {
    toast({
      title: "Edit OLT Type",
      description: `This functionality would edit OLT type with ID: ${id}`
    });
  };

  const handleDelete = (id: number) => {
    toast({
      title: "Delete OLT Type",
      description: `This functionality would delete OLT type with ID: ${id}`
    });
  };

  const handleExport = () => {
    toast({
      title: "Export OLTs List",
      description: "This functionality would export the OLT list."
    });
  };

  return (
    <div>
      <div className="flex justify-between mb-4">
        <h2 className="text-xl font-semibold">OLT Types</h2>
        <div className="flex gap-2">
          <Button 
            variant="default" 
            className="flex items-center gap-1"
            onClick={handleAdd}
          >
            <Plus className="h-4 w-4" /> Add OLT
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-1"
            onClick={handleExport}
          >
            Export OLTs list
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>View</TableHead>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>OLT IP</TableHead>
              <TableHead>Telnet/SSH TCP port</TableHead>
              <TableHead>IPTV</TableHead>
              <TableHead>OLT hardware version</TableHead>
              <TableHead>OLT SW version</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {oltTypes.map((oltType) => (
              <TableRow key={oltType.id}>
                <TableCell>
                  <Button 
                    variant="default" 
                    size="sm"
                  >
                    View
                  </Button>
                </TableCell>
                <TableCell>{oltType.id}</TableCell>
                <TableCell>{oltType.name}</TableCell>
                <TableCell>{oltType.ip}</TableCell>
                <TableCell>{oltType.telnetPort}</TableCell>
                <TableCell>{oltType.iptv}</TableCell>
                <TableCell>{oltType.hardwareVersion}</TableCell>
                <TableCell>{oltType.softwareVersion}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(oltType.id)}
                      className="h-8 w-8 text-gray-500 hover:text-gray-900"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(oltType.id)}
                      className="h-8 w-8 text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}