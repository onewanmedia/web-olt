import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Sample data - in a real app this would come from an API
const sampleOnuTypes = [
  {
    id: 1,
    ponType: 'GPON',
    onuType: 'ALL-GPON',
    ethernetPorts: 4,
    wifi: 8,
    voipPorts: 0,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 2,
    ponType: 'GPON',
    onuType: 'F-609',
    ethernetPorts: 4,
    wifi: 4,
    voipPorts: 0,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 3,
    ponType: 'GPON',
    onuType: 'F-660',
    ethernetPorts: 4,
    wifi: 4,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 4,
    ponType: 'GPON',
    onuType: 'F-670',
    ethernetPorts: 4,
    wifi: 8,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 5,
    ponType: 'GPON',
    onuType: 'F-670L',
    ethernetPorts: 4,
    wifi: 8,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 6,
    ponType: 'GPON',
    onuType: 'GM220-S',
    ethernetPorts: 4,
    wifi: 4,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 7,
    ponType: 'GPON',
    onuType: 'H640GW',
    ethernetPorts: 4,
    wifi: 4,
    voipPorts: 0,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 8,
    ponType: 'GPON',
    onuType: 'H640GW5',
    ethernetPorts: 0,
    wifi: 0,
    voipPorts: 0,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 9,
    ponType: 'GPON',
    onuType: 'HG6145D2',
    ethernetPorts: 4,
    wifi: 8,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 10,
    ponType: 'GPON',
    onuType: 'HG6145F',
    ethernetPorts: 4,
    wifi: 8,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  },
  {
    id: 11,
    ponType: 'GPON',
    onuType: 'HG8145V5',
    ethernetPorts: 4,
    wifi: 4,
    voipPorts: 2,
    catv: 0,
    allowCustomProfiles: 'yes',
    capability: 'Bridging/Routing'
  }
];

export default function OnuTypesSettings() {
  const { toast } = useToast();
  const [onuTypes, setOnuTypes] = useState(sampleOnuTypes);

  const handleAdd = () => {
    toast({
      title: "Add ONU Type",
      description: "This functionality would open a form to add a new ONU type."
    });
  };

  const handleDelete = (id: number) => {
    toast({
      title: "Delete ONU Type",
      description: `This functionality would delete ONU type with ID: ${id}`
    });
  };

  return (
    <div>
      <div className="flex justify-between mb-4">
        <h2 className="text-xl font-semibold">ONU Types</h2>
        <div className="flex gap-2">
          <Button 
            variant="default" 
            className="flex items-center gap-1"
            onClick={handleAdd}
          >
            <Plus className="h-4 w-4" /> Add ONU type
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>PON type</TableHead>
              <TableHead>ONU type</TableHead>
              <TableHead>Ethernet ports</TableHead>
              <TableHead>WiFi</TableHead>
              <TableHead>VoIP ports</TableHead>
              <TableHead>CATV</TableHead>
              <TableHead>Allow custom profiles</TableHead>
              <TableHead>Capability</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {onuTypes.map((onuType) => (
              <TableRow key={onuType.id}>
                <TableCell>{onuType.ponType}</TableCell>
                <TableCell>{onuType.onuType}</TableCell>
                <TableCell>{onuType.ethernetPorts}</TableCell>
                <TableCell>{onuType.wifi}</TableCell>
                <TableCell>{onuType.voipPorts}</TableCell>
                <TableCell>{onuType.catv}</TableCell>
                <TableCell>{onuType.allowCustomProfiles}</TableCell>
                <TableCell>{onuType.capability}</TableCell>
                <TableCell>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(onuType.id)}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}