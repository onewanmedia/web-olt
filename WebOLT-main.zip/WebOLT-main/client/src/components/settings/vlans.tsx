import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, MinusCircle } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";

// Sample data - in a real app this would come from an API
const sampleVlans = [
  {
    id: 20,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 2
  },
  {
    id: 21,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 1
  },
  {
    id: 22,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 2
  },
  {
    id: 23,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 1
  },
  {
    id: 24,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 0
  },
  {
    id: 25,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 2
  },
  {
    id: 26,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 1
  },
  {
    id: 50,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 1
  },
  {
    id: 88,
    defaultFor: "",
    description: "",
    usedForIPTV: false,
    usedForMgmtVoIP: false,
    dhcpSnooping: false,
    lanToLan: false,
    onus: 0
  }
];

export default function VlansSettings() {
  const { toast } = useToast();
  const [vlans, setVlans] = useState(sampleVlans);

  const handleAddVlan = () => {
    toast({
      title: "Add VLAN",
      description: "This functionality would open a form to add a new VLAN."
    });
  };

  const handleAddMultipleVlans = () => {
    toast({
      title: "Add Multiple VLANs",
      description: "This functionality would open a form to add multiple VLANs at once."
    });
  };

  const handleDeleteMultipleVlans = () => {
    toast({
      title: "Delete Multiple VLANs",
      description: "This functionality would delete selected VLANs."
    });
  };

  const handleDelete = (id: number) => {
    toast({
      title: "Delete VLAN",
      description: `This functionality would delete VLAN with ID: ${id}`
    });
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        <Button 
          variant="default" 
          className="flex items-center gap-1"
          onClick={handleAddVlan}
        >
          <Plus className="h-4 w-4" /> Add VLAN
        </Button>
        <Button 
          variant="default" 
          className="flex items-center gap-1"
          onClick={handleAddMultipleVlans}
        >
          <Plus className="h-4 w-4" /> Add multiple VLANs
        </Button>
        <Button 
          variant="default" 
          className="flex items-center gap-1 bg-red-500 hover:bg-red-600"
          onClick={handleDeleteMultipleVlans}
        >
          <MinusCircle className="h-4 w-4" /> Delete multiple VLANs
        </Button>
      </div>

      <p className="text-sm text-gray-600 mb-4">
        VLANs added here will not be applied to the Uplink ports automatically. Go to Uplink and tag the VLANs on the interfaces you want.
      </p>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="whitespace-nowrap">VLAN-ID</TableHead>
              <TableHead>Default for</TableHead>
              <TableHead>Description</TableHead>
              <TableHead className="text-center">Used for IPTV</TableHead>
              <TableHead className="text-center">Used for Mgmt/VoIP</TableHead>
              <TableHead className="text-center">DHCP Snooping</TableHead>
              <TableHead className="text-center">LAN to LAN</TableHead>
              <TableHead className="text-center">ONUs</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {vlans.map((vlan) => (
              <TableRow key={vlan.id}>
                <TableCell className="font-medium text-blue-600">
                  {vlan.id}
                </TableCell>
                <TableCell>{vlan.defaultFor}</TableCell>
                <TableCell>{vlan.description}</TableCell>
                <TableCell className="text-center">
                  <Checkbox 
                    checked={vlan.usedForIPTV} 
                    onCheckedChange={() => {}} 
                    className="mx-auto"
                  />
                </TableCell>
                <TableCell className="text-center">
                  <Checkbox 
                    checked={vlan.usedForMgmtVoIP} 
                    onCheckedChange={() => {}} 
                    className="mx-auto"
                  />
                </TableCell>
                <TableCell className="text-center">
                  <Checkbox 
                    checked={vlan.dhcpSnooping} 
                    onCheckedChange={() => {}} 
                    className="mx-auto"
                  />
                </TableCell>
                <TableCell className="text-center">
                  <Checkbox 
                    checked={vlan.lanToLan} 
                    onCheckedChange={() => {}} 
                    className="mx-auto"
                  />
                </TableCell>
                <TableCell className="text-center text-blue-600">
                  {vlan.onus}
                </TableCell>
                <TableCell>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(vlan.id)}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}