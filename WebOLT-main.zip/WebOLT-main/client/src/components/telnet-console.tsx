import { useEffect, useRef } from "react";

interface TelnetConsoleProps {
  output: string;
}

export default function TelnetConsole({ output }: TelnetConsoleProps) {
  const consoleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [output]);

  const formatOutput = (text: string) => {
    // Split by newlines and process each line
    return text.split('\n').map((line, index) => {
      // Check if line contains a command (starts with '>')
      if (line.startsWith('>')) {
        return (
          <div key={index} className="text-yellow-400">{line}</div>
        );
      }
      
      // Check if line contains an error message
      if (line.toLowerCase().includes('error') || line.startsWith('Error:')) {
        return (
          <div key={index} className="text-red-400">{line}</div>
        );
      }
      
      // Check if line contains successful status messages
      if (line.toLowerCase().includes('connected') || 
          line.toLowerCase().includes('success') || 
          line.toLowerCase().includes('successful')) {
        return (
          <div key={index} className="text-green-400">{line}</div>
        );
      }
      
      // Default formatting
      return (
        <div key={index}>{line}</div>
      );
    });
  };

  return (
    <div 
      ref={consoleRef}
      className="console h-96 p-4 overflow-y-auto font-mono text-sm bg-gray-900 text-green-400 whitespace-pre-wrap"
    >
      {output ? formatOutput(output) : (
        <div className="text-gray-500">
          Terminal ready. Connect to a device to start a session.
        </div>
      )}
    </div>
  );
}
