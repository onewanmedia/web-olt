import { useState } from "react";
import { useLocation } from "wouter";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { OnuDevice } from "@shared/schema";
import { Loader2, ChevronRight } from "lucide-react";

interface OnuTableProps {
  devices: OnuDevice[];
  isLoading: boolean;
}

export default function OnuTable({ devices, isLoading }: OnuTableProps) {
  const [, navigate] = useLocation();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  
  const totalItems = devices.length;
  const totalPages = Math.ceil(totalItems / pageSize);
  const start = (page - 1) * pageSize + 1;
  const end = Math.min(page * pageSize, totalItems);
  
  const currentPageDevices = devices.slice(start - 1, end);

  const handleViewDevice = (deviceId: number) => {
    navigate(`/onu/${deviceId}`);
  };
  
  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };
  
  const handlePageSizeChange = (value: string) => {
    setPageSize(parseInt(value));
    setPage(1); // Reset to first page when changing page size
  };

  // Card view for small devices, renders as a responsive grid of cards
  const renderCardView = () => {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4">
        {currentPageDevices.length === 0 ? (
          <div className="col-span-full text-center py-6 text-gray-500">
            No ONU devices found
          </div>
        ) : (
          currentPageDevices.map((device) => (
            <div key={device.id} className="bg-white border rounded-md shadow-sm p-4">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <span className={`inline-block rounded-full h-3 w-3 mr-2 ${
                    device.status === "online" ? "bg-green-500" : "bg-red-500"
                  }`}></span>
                  <span className="font-medium">{device.name}</span>
                </div>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => handleViewDevice(device.id)}
                  className="ml-2"
                >
                  View
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-gray-500">SN/MAC:</div>
                <div>{device.serialNumber}</div>
                
                <div className="text-gray-500">ONU:</div>
                <div>{device.oltIndex}</div>
                
                <div className="text-gray-500">Zone:</div>
                <div>{device.zone || 'N/A'}</div>
                
                <div className="text-gray-500">Signal:</div>
                <div>
                  {device.signal === 'good' ? (
                    <span className="text-green-500">Good</span>
                  ) : (
                    <span className="text-gray-400">Poor</span>
                  )}
                </div>
                
                <div className="text-gray-500">VLAN:</div>
                <div>{device.vlan}</div>
                
                <div className="text-gray-500">Type:</div>
                <div>{device.type}</div>
              </div>
            </div>
          ))
        )}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-md shadow-md p-8 text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
        <p className="text-gray-500">Loading ONU devices...</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-md shadow-md overflow-hidden">
      <div className="p-4 border-b border-gray-200 flex flex-wrap justify-between items-center">
        <h2 className="text-lg font-medium text-gray-800 mb-2 sm:mb-0">ONU Devices</h2>
        <div className="text-xs sm:text-sm text-gray-500">
          {totalItems > 0 ? `${start}-${end} ONUs of ${totalItems} displayed` : "No devices found"}
        </div>
      </div>
      
      {/* Table view for medium-large screens */}
      <div className="hidden md:block overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Status</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>SN/MAC</TableHead>
              <TableHead>ONU</TableHead>
              <TableHead>Zone</TableHead>
              <TableHead>ODB</TableHead>
              <TableHead>Signal</TableHead>
              <TableHead>B/R</TableHead>
              <TableHead>VLAN</TableHead>
              <TableHead>Type</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {currentPageDevices.length === 0 ? (
              <TableRow>
                <TableCell colSpan={11} className="text-center py-6 text-gray-500">
                  No ONU devices found
                </TableCell>
              </TableRow>
            ) : (
              currentPageDevices.map((device) => (
                <TableRow key={device.id}>
                  <TableCell>
                    <span className="flex h-3 w-3">
                      <span className={`relative inline-flex rounded-full h-3 w-3 ${
                        device.status === "online" ? "bg-green-500" : "bg-red-500"
                      }`}></span>
                    </span>
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => handleViewDevice(device.id)}
                    >
                      View
                    </Button>
                  </TableCell>
                  <TableCell className="font-medium">{device.name}</TableCell>
                  <TableCell className="text-gray-500">{device.serialNumber}</TableCell>
                  <TableCell className="text-gray-500">{device.oltIndex}</TableCell>
                  <TableCell className="text-gray-500">{device.zone || 'N/A'}</TableCell>
                  <TableCell className="text-gray-500">{device.odb || 'None'}</TableCell>
                  <TableCell>
                    {device.signal === 'good' ? (
                      <span className="text-green-500">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"></path>
                        </svg>
                      </span>
                    ) : (
                      <span className="text-gray-400">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"></path>
                        </svg>
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-gray-500">{device.bridgeRouter}</TableCell>
                  <TableCell className="text-gray-500">{device.vlan}</TableCell>
                  <TableCell className="text-gray-500">{device.type}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Card view for mobile screens */}
      <div className="md:hidden">
        {renderCardView()}
      </div>
      
      <div className="p-2 sm:p-4 border-t border-gray-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center w-full sm:w-auto">
          <Select
            value={pageSize.toString()}
            onValueChange={handlePageSizeChange}
          >
            <SelectTrigger className="w-full sm:w-[130px] mb-2 sm:mb-0">
              <SelectValue placeholder="Rows per page" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="10">10 per page</SelectItem>
              <SelectItem value="25">25 per page</SelectItem>
              <SelectItem value="50">50 per page</SelectItem>
              <SelectItem value="100">100 per page</SelectItem>
            </SelectContent>
          </Select>
          <span className="sm:ml-2 text-xs sm:text-sm text-gray-600 mb-2 sm:mb-0">
            {totalItems > 0 ? `Showing ${start}-${end} of ${totalItems} items` : "No items to display"}
          </span>
        </div>
        <div className="flex items-center space-x-1 sm:space-x-2 w-full sm:w-auto justify-between sm:justify-end">
          <Button
            variant="outline"
            size="sm"
            className="px-2 sm:px-3"
            onClick={() => handlePageChange(page - 1)}
            disabled={page <= 1}
          >
            Previous
          </Button>
          {totalPages > 0 && (
            <Button
              variant={page === 1 ? "default" : "outline"}
              size="sm"
              className="px-2 sm:px-3"
              onClick={() => handlePageChange(1)}
            >
              1
            </Button>
          )}
          {totalPages > 1 && page !== 1 && page !== totalPages && (
            <Button
              variant="default"
              size="sm"
              className="px-2 sm:px-3"
            >
              {page}
            </Button>
          )}
          {totalPages > 2 && page !== totalPages && (
            <Button
              variant={page === totalPages ? "default" : "outline"}
              size="sm"
              className="px-2 sm:px-3"
              onClick={() => handlePageChange(totalPages)}
            >
              {totalPages}
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            className="px-2 sm:px-3"
            onClick={() => handlePageChange(page + 1)}
            disabled={page >= totalPages}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
