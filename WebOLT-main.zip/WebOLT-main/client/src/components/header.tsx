import { useState } from "react";
import { useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { UserCircle, LogOut, Menu, X, ChevronDown } from "lucide-react";

export default function Header() {
  const [, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleProfileClick = () => {
    setIsDropdownOpen(false);
    navigate("/profile");
  };
  
  const handleLogout = async () => {
    setIsDropdownOpen(false);
    await logoutMutation.mutateAsync();
    navigate("/auth");
  };
  
  const getInitials = () => {
    if (!user) return "U";
    
    if (user.firstName && user.lastName) {
      return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
    }
    
    return user.username.charAt(0).toUpperCase();
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="flex justify-between items-center px-4 sm:px-6 py-3">
        <div className="flex items-center">
          <h1 className="text-xl font-bold text-primary mr-4" onClick={() => navigate("/")} style={{ cursor: "pointer" }}>WebOLT</h1>
          <nav className="hidden md:flex space-x-4 lg:space-x-6">
            <a 
              href="/register-onu" 
              onClick={(e) => { e.preventDefault(); navigate("/register-onu"); }} 
              className="text-gray-600 hover:text-primary px-1 py-2"
            >
              Register ONU
            </a>
            <a 
              href="/unconfigured" 
              onClick={(e) => { e.preventDefault(); navigate("/unconfigured"); }} 
              className="text-gray-600 hover:text-primary px-1 py-2"
            >
              Unconfigured
            </a>
            <a 
              href="/" 
              onClick={(e) => { e.preventDefault(); navigate("/"); }} 
              className="text-primary border-b-2 border-primary px-1 py-2"
            >
              Configured
            </a>
            <a 
              href="/graphs" 
              onClick={(e) => { e.preventDefault(); navigate("/graphs"); }} 
              className="text-gray-600 hover:text-primary px-1 py-2"
            >
              Graphs
            </a>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <a href="#" className="text-gray-600 hover:text-primary px-1 py-2 flex items-center">
                  Settings <ChevronDown className="ml-1 h-4 w-4" />
                </a>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/olt-types"); }}>
                  <span className="flex w-full">OLT Types</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/onu-types"); }}>
                  <span className="flex w-full">ONU Types</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/vlans"); }}>
                  <span className="flex w-full">VLANs</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/billing"); }}>
                  <span className="flex w-full">Billing</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/billing?tab=payment-methods"); }}>
                  <span className="flex w-full">Metode Pembayaran</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/billing?tab=invoices"); }}>
                  <span className="flex w-full">Invoices</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/users"); }}>
                  <span className="flex w-full">Users</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => { setIsDropdownOpen(false); navigate("/settings/system"); }}>
                  <span className="flex w-full">System Settings</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
        </div>
        <div className="flex items-center">
          <button 
            className="md:hidden mr-2 p-2 focus:outline-none" 
            onClick={toggleMobileMenu}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          <DropdownMenu open={isDropdownOpen} onOpenChange={setIsDropdownOpen}>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar>
                  <AvatarImage src="" alt={user?.username || "User"} />
                  <AvatarFallback className="bg-primary text-white">{getInitials()}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end">
              <DropdownMenuItem onClick={handleProfileClick}>
                <UserCircle className="mr-2 h-4 w-4" />
                <span>My Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 py-2">
          <nav className="flex flex-col px-4">
            <a 
              href="/register-onu" 
              onClick={(e) => { 
                e.preventDefault(); 
                navigate("/register-onu"); 
                setMobileMenuOpen(false);
              }} 
              className="text-gray-600 hover:text-primary py-2"
            >
              Register ONU
            </a>
            <a 
              href="/unconfigured" 
              onClick={(e) => { 
                e.preventDefault(); 
                navigate("/unconfigured"); 
                setMobileMenuOpen(false);
              }} 
              className="text-gray-600 hover:text-primary py-2"
            >
              Unconfigured
            </a>
            <a 
              href="/" 
              onClick={(e) => { 
                e.preventDefault(); 
                navigate("/"); 
                setMobileMenuOpen(false);
              }} 
              className="text-primary py-2 font-medium"
            >
              Configured
            </a>
            <a 
              href="/graphs" 
              onClick={(e) => { 
                e.preventDefault(); 
                navigate("/graphs"); 
                setMobileMenuOpen(false);
              }} 
              className="text-gray-600 hover:text-primary py-2"
            >
              Graphs
            </a>
            <div className="py-2">
              <div className="text-gray-600 py-2 font-medium">Settings</div>
              <div className="pl-4 flex flex-col space-y-2">
                <a 
                  href="/settings/olt-types" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/olt-types"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  OLT Types
                </a>
                <a 
                  href="/settings/onu-types" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/onu-types"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  ONU Types
                </a>
                <a 
                  href="/settings/vlans" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/vlans"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  VLANs
                </a>

                <div className="border-t border-gray-200 my-1 pt-1"></div>
                <a 
                  href="/settings/billing" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/billing"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  Billing
                </a>
                <a 
                  href="/settings/billing?tab=payment-methods" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/billing?tab=payment-methods"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  Metode Pembayaran
                </a>
                <a 
                  href="/settings/billing?tab=invoices" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/billing?tab=invoices"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  Invoices
                </a>
                <div className="border-t border-gray-200 my-1 pt-1"></div>
                <a 
                  href="/settings/users" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/users"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  Users
                </a>
                <a 
                  href="/settings/system" 
                  onClick={(e) => { 
                    e.preventDefault(); 
                    navigate("/settings/system"); 
                    setMobileMenuOpen(false);
                  }} 
                  className="text-gray-600 hover:text-primary py-1 text-sm"
                >
                  System Settings
                </a>
              </div>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
