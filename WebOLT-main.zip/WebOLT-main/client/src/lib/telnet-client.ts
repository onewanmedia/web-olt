import { apiRequest } from "./queryClient";

export class TelnetClientError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "TelnetClientError";
  }
}

export interface TelnetConnection {
  ipAddress: string;
  username: string;
  password: string;
  port: number;
}

export interface CommandResult {
  status: string;
  command: string;
  response: string;
}

export class TelnetClient {
  private connectionId: string | null = null;
  private connected: boolean = false;
  private oltDeviceId?: number;

  constructor(oltDeviceId?: number) {
    this.oltDeviceId = oltDeviceId;
  }

  public async connect(connection: TelnetConnection): Promise<string> {
    try {
      const response = await apiRequest("POST", "/api/telnet/connect", connection);
      const data = await response.json();
      
      if (data.status === "connected" && data.connectionId) {
        this.connectionId = data.connectionId;
        this.connected = true;
        return data.message;
      } else {
        throw new TelnetClientError(data.message || "Failed to connect");
      }
    } catch (error) {
      throw new TelnetClientError(error.message || "Connection failed");
    }
  }

  public async executeCommand(command: string): Promise<CommandResult> {
    if (!this.connectionId || !this.connected) {
      throw new TelnetClientError("Not connected. Please connect first.");
    }

    try {
      const payload = {
        connectionId: this.connectionId,
        command,
        ...(this.oltDeviceId ? { oltDeviceId: this.oltDeviceId } : {})
      };
      
      const response = await apiRequest("POST", "/api/telnet/execute", payload);
      return await response.json();
    } catch (error) {
      throw new TelnetClientError(error.message || "Command execution failed");
    }
  }

  public async disconnect(): Promise<void> {
    if (!this.connectionId) {
      return;
    }

    try {
      await apiRequest("POST", "/api/telnet/disconnect", { connectionId: this.connectionId });
      this.connectionId = null;
      this.connected = false;
    } catch (error) {
      throw new TelnetClientError(error.message || "Disconnect failed");
    }
  }

  public isConnected(): boolean {
    return this.connected;
  }

  public getConnectionId(): string | null {
    return this.connectionId;
  }
}

export default TelnetClient;
