import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowLeft, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/header";
import TelnetConsole from "@/components/telnet-console";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface CommandHistoryItem {
  id: number;
  command: string;
  timestamp: string;
  status: string;
}

export default function ConsolePage() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [connectionId, setConnectionId] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<"disconnected" | "connecting" | "connected">("disconnected");
  const [commandHistory, setCommandHistory] = useState<CommandHistoryItem[]>([]);
  const [consoleOutput, setConsoleOutput] = useState<string>("");
  
  const [connectionSettings, setConnectionSettings] = useState({
    ipAddress: "192.168.1.10",
    username: "admin",
    password: "admin",
    port: 23
  });
  
  const [currentCommand, setCurrentCommand] = useState("");
  
  // Fetch OLT device if ID is provided
  const { data: oltDevice } = useQuery({
    queryKey: ["/api/olt-devices", params.id],
    enabled: !!params.id,
    onSuccess: (data) => {
      if (data) {
        setConnectionSettings({
          ipAddress: data.ipAddress,
          username: data.username,
          password: data.password,
          port: data.port
        });
      }
    }
  });
  
  // Fetch command history if OLT device ID is provided
  const { data: historyData } = useQuery({
    queryKey: ["/api/command-history", params.id],
    enabled: !!params.id,
    onSuccess: (data) => {
      if (data) {
        setCommandHistory(data);
      }
    }
  });
  
  // Fetch saved commands
  const { data: savedCommands = [] } = useQuery({
    queryKey: ["/api/saved-commands"],
  });
  
  const connectMutation = useMutation({
    mutationFn: async (data: typeof connectionSettings) => {
      const res = await apiRequest("POST", "/api/telnet/connect", data);
      return await res.json();
    },
    onSuccess: (data) => {
      setConnectionId(data.connectionId);
      setConnectionStatus("connected");
      setConsoleOutput(prev => prev + "\nConnected to " + connectionSettings.ipAddress);
      toast({
        title: "Connected",
        description: `Successfully connected to ${connectionSettings.ipAddress}`,
      });
    },
    onError: (error: Error) => {
      setConnectionStatus("disconnected");
      toast({
        title: "Connection Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      if (!connectionId) return;
      const res = await apiRequest("POST", "/api/telnet/disconnect", { connectionId });
      return await res.json();
    },
    onSuccess: () => {
      setConnectionId(null);
      setConnectionStatus("disconnected");
      setConsoleOutput(prev => prev + "\nDisconnected");
      toast({
        title: "Disconnected",
        description: "Terminal session closed",
      });
    }
  });
  
  const executeCommandMutation = useMutation({
    mutationFn: async (command: string) => {
      if (!connectionId) throw new Error("Not connected");
      const payload = {
        connectionId,
        command,
        ...(params.id ? { oltDeviceId: parseInt(params.id) } : {})
      };
      const res = await apiRequest("POST", "/api/telnet/execute", payload);
      return await res.json();
    },
    onSuccess: (data) => {
      setConsoleOutput(prev => `${prev}\n> ${data.command}\n${data.response}`);
      if (params.id) {
        queryClient.invalidateQueries({ queryKey: ["/api/command-history", params.id] });
      }
    },
    onError: (error: Error) => {
      setConsoleOutput(prev => `${prev}\nError: ${error.message}`);
      toast({
        title: "Command Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleConnect = () => {
    setConnectionStatus("connecting");
    connectMutation.mutate(connectionSettings);
  };
  
  const handleDisconnect = () => {
    disconnectMutation.mutate();
  };
  
  const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setConnectionSettings(prev => ({
      ...prev,
      [name]: name === "port" ? parseInt(value) : value
    }));
  };
  
  const handleCommandChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentCommand(e.target.value);
  };
  
  const handleSendCommand = () => {
    if (!currentCommand.trim() || !connectionId) return;
    
    executeCommandMutation.mutate(currentCommand);
    setCurrentCommand("");
  };
  
  const handleSavedCommandClick = (command: string) => {
    if (!connectionId) {
      toast({
        title: "Not Connected",
        description: "Please connect to a device first",
        variant: "destructive",
      });
      return;
    }
    
    executeCommandMutation.mutate(command);
  };
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (connectionId) {
        disconnectMutation.mutate();
      }
    };
  }, [connectionId]);
  
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          <Button 
            variant="ghost" 
            className="flex items-center text-primary hover:text-primary/80 mr-4"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
          </Button>
          <h2 className="text-2xl font-bold text-gray-800">OLT Command Console</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <h3 className="text-lg font-medium text-gray-800">Connection Details</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="ipAddress">OLT IP Address</Label>
                    <Input
                      id="ipAddress"
                      name="ipAddress"
                      value={connectionSettings.ipAddress}
                      onChange={handleSettingsChange}
                      disabled={connectionStatus !== "disconnected"}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      name="username"
                      value={connectionSettings.username}
                      onChange={handleSettingsChange}
                      disabled={connectionStatus !== "disconnected"}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      value={connectionSettings.password}
                      onChange={handleSettingsChange}
                      disabled={connectionStatus !== "disconnected"}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="port">Port</Label>
                    <Input
                      id="port"
                      name="port"
                      type="number"
                      value={connectionSettings.port.toString()}
                      onChange={handleSettingsChange}
                      disabled={connectionStatus !== "disconnected"}
                    />
                  </div>
                  
                  {connectionStatus === "disconnected" ? (
                    <Button 
                      className="w-full" 
                      onClick={handleConnect} 
                      disabled={connectMutation.isPending}
                    >
                      {connectMutation.isPending ? "Connecting..." : "Connect"}
                    </Button>
                  ) : (
                    <Button 
                      className="w-full" 
                      variant="destructive"
                      onClick={handleDisconnect} 
                      disabled={disconnectMutation.isPending}
                    >
                      {disconnectMutation.isPending ? "Disconnecting..." : "Disconnect"}
                    </Button>
                  )}
                </div>
                
                <div className="mt-6">
                  <h3 className="text-lg font-medium text-gray-800 mb-4">Saved Commands</h3>
                  
                  <div className="space-y-2">
                    {savedCommands.length === 0 ? (
                      <p className="text-gray-500 text-sm">No saved commands</p>
                    ) : (
                      savedCommands.map((cmd) => (
                        <Button 
                          key={cmd.id}
                          variant="outline" 
                          className="text-left w-full justify-start"
                          onClick={() => handleSavedCommandClick(cmd.command)}
                        >
                          {cmd.command}
                        </Button>
                      ))
                    )}
                    
                    <Button 
                      variant="outline" 
                      className="text-left w-full justify-start"
                      onClick={() => handleSavedCommandClick("show running-config")}
                    >
                      show running-config
                    </Button>
                    <Button 
                      variant="outline" 
                      className="text-left w-full justify-start"
                      onClick={() => handleSavedCommandClick("show interface gpon-olt")}
                    >
                      show interface gpon-olt
                    </Button>
                    <Button 
                      variant="outline" 
                      className="text-left w-full justify-start"
                      onClick={() => handleSavedCommandClick("show gpon onu uncfg")}
                    >
                      show gpon onu uncfg
                    </Button>
                    <Button 
                      variant="outline" 
                      className="text-left w-full justify-start"
                      onClick={() => handleSavedCommandClick("show gpon onu state")}
                    >
                      show gpon onu state
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-2">
            <Card className="overflow-hidden">
              <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-800 text-white">
                <h3 className="text-lg font-medium">Command Console</h3>
                <div className="flex items-center space-x-2">
                  <Badge variant={connectionStatus === "connected" ? "default" : "destructive"}>
                    {connectionStatus === "connected" ? "Connected" : "Disconnected"}
                  </Badge>
                </div>
              </div>
              
              <TelnetConsole output={consoleOutput} />
              
              <div className="p-4 border-t border-gray-200 bg-gray-800">
                <div className="flex">
                  <Input
                    type="text"
                    placeholder="Enter command..."
                    value={currentCommand}
                    onChange={handleCommandChange}
                    onKeyDown={(e) => e.key === "Enter" && handleSendCommand()}
                    className="flex-1 bg-gray-700 text-white border-gray-600 focus-visible:ring-primary"
                    disabled={connectionStatus !== "connected" || executeCommandMutation.isPending}
                  />
                  <Button 
                    className="ml-2" 
                    onClick={handleSendCommand}
                    disabled={connectionStatus !== "connected" || !currentCommand.trim() || executeCommandMutation.isPending}
                  >
                    <Send className="h-4 w-4 mr-2" /> Send
                  </Button>
                </div>
              </div>
            </Card>
            
            <Card className="mt-6">
              <CardHeader className="pb-3">
                <h3 className="text-lg font-medium text-gray-800">Command History</h3>
              </CardHeader>
              <CardContent>
                {commandHistory.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">
                    <p>No command history yet</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Timestamp</TableHead>
                        <TableHead>Command</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {commandHistory.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-mono text-sm">
                            {format(new Date(item.timestamp), "yyyy-MM-dd HH:mm:ss")}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {item.command}
                          </TableCell>
                          <TableCell>
                            <Badge variant={item.status === "success" ? "default" : "destructive"}>
                              {item.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
