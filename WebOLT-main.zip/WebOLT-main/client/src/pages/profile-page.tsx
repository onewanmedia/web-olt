import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Mail, Calendar, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/header";
import { format } from "date-fns";

export default function ProfilePage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [profileData, setProfileData] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    email: user?.email || "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: Partial<typeof profileData>) => {
      const res = await apiRequest("PATCH", "/api/user", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate password change
    if (profileData.newPassword || profileData.currentPassword || profileData.confirmPassword) {
      if (!profileData.currentPassword) {
        toast({
          title: "Password Error",
          description: "Current password is required to change password",
          variant: "destructive",
        });
        return;
      }
      
      if (profileData.newPassword !== profileData.confirmPassword) {
        toast({
          title: "Password Error",
          description: "New passwords don't match",
          variant: "destructive",
        });
        return;
      }
    }
    
    // Remove password fields if they're not being changed
    const dataToUpdate = {
      firstName: profileData.firstName,
      lastName: profileData.lastName,
      email: profileData.email,
    };
    
    updateProfileMutation.mutate(dataToUpdate);
  };
  
  const formattedRegisteredDate = user?.registeredAt 
    ? format(new Date(user.registeredAt), "dd MMM yyyy HH:mm:ss")
    : "N/A";
    
  const formattedLastLogin = user?.lastLogin
    ? format(new Date(user.lastLogin), "dd MMM yyyy HH:mm:ss")
    : "N/A";
  
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center mb-6">
          <Button 
            variant="ghost" 
            className="flex items-center text-primary hover:text-primary/80 mr-4"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
          </Button>
          <h2 className="text-2xl font-bold text-gray-800">My Profile</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <div className="bg-primary/20 rounded-lg p-6 flex flex-col items-center">
              <div className="w-32 h-32 rounded-full bg-primary flex items-center justify-center overflow-hidden mb-4">
                <svg className="h-24 w-24 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
              </div>
              <Button className="bg-primary text-white hover:bg-primary/80 mt-2 w-full">
                Change Photo
              </Button>
              <h3 className="text-xl font-bold text-gray-800 mt-4">{user?.firstName} {user?.lastName}</h3>
              <p className="text-gray-600">{user?.email}</p>
            </div>
            
            <Card className="mt-6">
              <CardHeader className="pb-3">
                <h3 className="text-lg font-medium text-gray-800 flex items-center">
                  <span className="mr-2 text-primary">💳</span> Payment History
                </h3>
              </CardHeader>
              <CardContent>
                <div className="text-center text-gray-500 py-8">
                  <span className="block text-4xl mb-4 text-gray-300">🧾</span>
                  <p>No payment history available</p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="md:col-span-2">
            <Card>
              <CardHeader className="pb-3">
                <h3 className="text-lg font-medium text-gray-800">Information</h3>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        name="firstName"
                        value={profileData.firstName}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        name="lastName"
                        value={profileData.lastName}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label>Email</Label>
                    <div className="flex items-center mt-1">
                      <Mail className="h-4 w-4 text-gray-500 mr-2" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={profileData.email}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label>Registered Date</Label>
                    <div className="flex items-center mt-1">
                      <Calendar className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-gray-700">{formattedRegisteredDate}</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label>Last Login</Label>
                    <div className="flex items-center mt-1">
                      <Clock className="h-4 w-4 text-gray-500 mr-2" />
                      <span className="text-gray-700">{formattedLastLogin}</span>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-200">
                    <h4 className="text-md font-medium text-gray-800 mb-4">Change Password</h4>
                    
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="currentPassword">Current Password</Label>
                        <Input
                          id="currentPassword"
                          name="currentPassword"
                          type="password"
                          placeholder="Enter your current password"
                          value={profileData.currentPassword}
                          onChange={handleInputChange}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="newPassword">New Password</Label>
                        <Input
                          id="newPassword"
                          name="newPassword"
                          type="password"
                          placeholder="Enter new password"
                          value={profileData.newPassword}
                          onChange={handleInputChange}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="confirmPassword">Confirm New Password</Label>
                        <Input
                          id="confirmPassword"
                          name="confirmPassword"
                          type="password"
                          placeholder="Confirm new password"
                          value={profileData.confirmPassword}
                          onChange={handleInputChange}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end pt-4">
                    <Button type="button" variant="outline" className="mr-2" onClick={() => navigate("/")}>
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
