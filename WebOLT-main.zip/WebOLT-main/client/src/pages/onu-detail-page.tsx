import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { OnuDevice } from "@shared/schema";
import Header from "@/components/header";
import { Loader2, AlertCircle, Eye, RefreshCw, Terminal } from "lucide-react";

export default function OnuDetailPage() {
  const [, navigate] = useLocation();
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");

  // Fetch ONU device
  const { data: onuDevice, isLoading, error } = useQuery({
    queryKey: ['/api/onu-devices', parseInt(id)],
    queryFn: async () => {
      const res = await fetch(`/api/onu-devices/${id}`);
      if (!res.ok) {
        throw new Error("Failed to fetch ONU device");
      }
      return res.json() as Promise<OnuDevice>;
    }
  });

  // Fetch OLT device
  const { data: oltDevice } = useQuery({
    queryKey: ['/api/olt-devices', onuDevice?.oltDeviceId],
    queryFn: async () => {
      if (!onuDevice?.oltDeviceId) return null;
      const res = await fetch(`/api/olt-devices/${onuDevice.oltDeviceId}`);
      if (!res.ok) {
        throw new Error("Failed to fetch OLT device");
      }
      return res.json();
    },
    enabled: !!onuDevice?.oltDeviceId
  });

  const handleBackClick = () => {
    navigate("/");
  };

  const handleGetStatus = () => {
    toast({
      title: "Getting status...",
      description: "This functionality would connect to the OLT and check the ONU status."
    });
  };

  const handleShowConfig = () => {
    toast({
      title: "Showing config...",
      description: "This functionality would retrieve the running configuration."
    });
  };

  const handleSWInfo = () => {
    toast({
      title: "Fetching SW info...",
      description: "This functionality would fetch software information from the ONU."
    });
  };

  const handleLiveAccess = () => {
    toast({
      title: "Live access...",
      description: "This functionality would provide real-time access to the ONU."
    });
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 container py-4">
          <div className="flex justify-center items-center h-96">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">Loading ONU details...</span>
          </div>
        </main>
      </div>
    );
  }

  if (error || !onuDevice) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 container py-4">
          <Alert variant="destructive" className="my-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Error loading ONU device details. {error instanceof Error ? error.message : ""}
            </AlertDescription>
          </Alert>
          <Button onClick={handleBackClick} className="mt-4">Back to List</Button>
        </main>
      </div>
    );
  }

  // Mock data for traffic graphs
  const uploadData = [0.1, 0.3, 0.6, 0.2, 0.8, 0.5, 0.4, 0.7, 0.3, 0.6, 0.5];
  const downloadData = [0.5, 0.7, 1.2, 0.8, 1.5, 1.2, 0.9, 1.4, 0.8, 1.0, 0.8];

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 py-4">
        <div className="container">
          <div className="flex justify-between items-center mb-4">
            <Button variant="outline" onClick={handleBackClick}>Back to OLTs List</Button>
            {onuDevice.authDate && (
              <Badge variant="outline" className="text-green-600 border-green-600">
                Configured
              </Badge>
            )}
            {!onuDevice.authDate && (
              <Badge variant="outline" className="text-amber-600 border-amber-600">
                Unconfigured
              </Badge>
            )}
          </div>

          {/* Alert for imported settings */}
          <Alert className="mb-4 bg-amber-100 border-amber-300">
            <AlertDescription>
              The settings of this ONU were imported. Please use the 'Resync config' button before doing any changes to the ONU.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">ONU Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="mb-4">
                      <TabsTrigger value="general">General</TabsTrigger>
                      <TabsTrigger value="network">Network</TabsTrigger>
                      <TabsTrigger value="traffic">Traffic</TabsTrigger>
                    </TabsList>

                    <TabsContent value="general">
                      <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                        <div className="text-sm text-gray-600">OLT</div>
                        <div className="text-sm font-medium">{oltDevice?.name || 'Loading...'}</div>
                        
                        <div className="text-sm text-gray-600">Board</div>
                        <div className="text-sm font-medium">1</div>
                        
                        <div className="text-sm text-gray-600">Port</div>
                        <div className="text-sm font-medium">1 (jl tanah merah 4 gg langgar)</div>
                        
                        <div className="text-sm text-gray-600">ONU</div>
                        <div className="text-sm font-medium">gpon-onu_1/1/1:19</div>
                        
                        <div className="text-sm text-gray-600">SN</div>
                        <div className="text-sm font-medium">{onuDevice.serialNumber}</div>
                        
                        <div className="text-sm text-gray-600">ONU Type</div>
                        <div className="text-sm font-medium">{onuDevice.type || 'ZXH-F670'}</div>
                        
                        <div className="text-sm text-gray-600">Zone</div>
                        <div className="text-sm font-medium">{onuDevice.zone || 'Zone 1'}</div>
                        
                        <div className="text-sm text-gray-600">ODB (Splitter)</div>
                        <div className="text-sm font-medium">{onuDevice.odb || 'None'}</div>
                        
                        <div className="text-sm text-gray-600">Name</div>
                        <div className="text-sm font-medium">{onuDevice.name}</div>
                        
                        <div className="text-sm text-gray-600">Address or comment</div>
                        <div className="text-sm font-medium">tanah merah gg 4</div>
                        
                        <div className="text-sm text-gray-600">Contact</div>
                        <div className="text-sm font-medium">None</div>
                        
                        <div className="text-sm text-gray-600">Authorization date</div>
                        <div className="text-sm font-medium">{onuDevice.authDate ? new Date(onuDevice.authDate).toLocaleString() : 'History'}</div>
                        
                        <div className="text-sm text-gray-600">ONU External ID</div>
                        <div className="text-sm font-medium">{onuDevice.serialNumber}</div>
                      </div>

                      {/* Ethernet Ports Section */}
                      <div className="mt-8">
                        <h3 className="text-base font-medium mb-3">Ethernet ports</h3>
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                              <tr>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Port</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Admin state</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mode</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DHCP</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {["eth_0/1", "eth_0/2", "eth_0/3", "eth_0/4"].map((port) => (
                                <tr key={port}>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">{port}</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">Enabled</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">LAN</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">From ONU</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">
                                    <Button 
                                      variant="outline" 
                                      size="sm" 
                                      className="text-blue-500 text-xs"
                                      onClick={() => toast({
                                        title: "Configuration",
                                        description: `Configuring port ${port}...`,
                                      })}
                                    >
                                      Configure
                                    </Button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      {/* WiFi Section */}
                      <div className="mt-6">
                        <div className="flex items-center mb-3">
                          <h3 className="text-base font-medium">WiFi</h3>
                          <div className="ml-4 flex items-center">
                            <input
                              type="checkbox"
                              id="enable-wifi"
                              className="rounded border-gray-300 text-primary focus:ring-primary h-4 w-4"
                              defaultChecked={true}
                            />
                            <label htmlFor="enable-wifi" className="ml-2 text-sm text-gray-700">
                              Enable
                            </label>
                          </div>
                        </div>
                        
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                              <tr>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Port</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Admin state</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mode</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SSID</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DHCP</th>
                                <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {[
                                { port: "wifi_0/1", state: "Enabled", mode: "Access VLAN: 26", control: "No control" },
                                { port: "wifi_0/2", state: "Disabled", mode: "LAN", control: "No control" },
                                { port: "wifi_0/3", state: "Disabled", mode: "LAN", control: "No control" },
                                { port: "wifi_0/4", state: "Disabled", mode: "LAN", control: "No control" },
                                { port: "wifi_0/5", state: "Enabled", mode: "LAN", control: "No control" },
                                { port: "wifi_0/6", state: "Disabled", mode: "LAN", control: "No control" },
                                { port: "wifi_0/7", state: "Disabled", mode: "LAN", control: "No control" },
                                { port: "wifi_0/8", state: "Disabled", mode: "LAN", control: "No control" }
                              ].map((wifi) => (
                                <tr key={wifi.port}>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">{wifi.port}</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">{wifi.state}</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">{wifi.mode}</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm"></td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">{wifi.control}</td>
                                  <td className="px-4 py-2 whitespace-nowrap text-sm">
                                    <Button 
                                      variant="outline" 
                                      size="sm" 
                                      className="text-blue-500 text-xs"
                                      onClick={() => toast({
                                        title: "Configuration", 
                                        description: `Configuring WiFi port ${wifi.port}...`
                                      })}
                                    >
                                      Configure
                                    </Button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      {/* VoIP and CATV Section */}
                      <div className="mt-6">
                        <div className="grid grid-cols-4 gap-4">
                          <div>
                            <h3 className="text-base font-medium">VoIP service</h3>
                            <p className="text-sm text-gray-500 mt-1">Disabled</p>
                          </div>
                          <div>
                            <h3 className="text-base font-medium">CATV</h3>
                            <p className="text-sm text-gray-500 mt-1">Not supported by ONU-Type.</p>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="mt-6 flex flex-wrap gap-2">
                        <Button variant="outline" className="flex items-center gap-1 bg-amber-100 hover:bg-amber-200 border-amber-300">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-power"><path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.77.04"/></svg>
                          Reboot
                        </Button>
                        <Button variant="outline" className="flex items-center gap-1 bg-amber-100 hover:bg-amber-200 border-amber-300">
                          <RefreshCw className="h-4 w-4" />
                          Resync config
                        </Button>
                        <Button variant="outline" className="flex items-center gap-1 bg-amber-100 hover:bg-amber-200 border-amber-300">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-undo"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/></svg>
                          Restore defaults
                        </Button>
                        <Button variant="outline" className="flex items-center gap-1">
                          Disable ONU
                        </Button>
                        <Button variant="outline" className="flex items-center gap-1 bg-red-100 hover:bg-red-200 border-red-300 text-red-600">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trash-2"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                          Delete
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="network">
                      <div className="grid grid-cols-2 gap-x-8 gap-y-2">
                        <div className="text-sm text-gray-600">Status</div>
                        <div className="text-sm font-medium flex items-center">
                          Online <span className="ml-1 w-2 h-2 rounded-full bg-green-500"></span>
                        </div>
                        
                        <div className="text-sm text-gray-600">ONU/OLT Rx Signal</div>
                        <div className="text-sm font-medium">-25.69 dBm / -30.21 dBm (239m)</div>
                        
                        <div className="text-sm text-gray-600">Attached VLANs</div>
                        <div className="text-sm font-medium">1000, 26</div>
                        
                        <div className="text-sm text-gray-600">ONU mode</div>
                        <div className="text-sm font-medium">Routing - WAN vlan: 1000</div>
                        
                        <div className="text-sm text-gray-600">TR069</div>
                        <div className="text-sm font-medium">Inactive</div>
                        
                        <div className="text-sm text-gray-600">Mgmt IP</div>
                        <div className="text-sm font-medium">Inactive</div>
                        
                        <div className="text-sm text-gray-600">WAN setup mode</div>
                        <div className="text-sm font-medium">PPPoE - 192.168.99.252</div>
                        
                        <div className="text-sm text-gray-600">PPPoE username</div>
                        <div className="text-sm font-medium flex items-center">
                          ririn <Eye className="ml-1 h-4 w-4 text-blue-500" />
                        </div>
                        
                        <div className="text-sm text-gray-600">PPPoE password</div>
                        <div className="text-sm font-medium flex items-center">
                          ririn <Eye className="ml-1 h-4 w-4 text-blue-500" />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="traffic">
                      <div className="space-y-6">
                        <div>
                          <h3 className="font-medium mb-2">Traffic/Signal</h3>
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                            <div className="bg-gray-50 p-4 rounded">
                              <h4 className="text-sm font-medium mb-2">gpon-onu_1/1/1:19 daily traffic</h4>
                              <div className="h-40 relative">
                                {/* Simulated traffic graph */}
                                <div className="absolute bottom-0 left-0 right-0 h-full flex items-end">
                                  {uploadData.map((val, i) => (
                                    <div key={`up-${i}`} className="flex-1 mx-px">
                                      <div 
                                        className="bg-blue-500 w-full" 
                                        style={{ height: `${val * 40}%` }}
                                        title={`${val.toFixed(2)} Mbps`}
                                      ></div>
                                    </div>
                                  ))}
                                </div>
                                <div className="absolute bottom-0 left-0 right-0 h-full flex items-end">
                                  {downloadData.map((val, i) => (
                                    <div key={`down-${i}`} className="flex-1 mx-px">
                                      <div 
                                        className="bg-red-500 w-full opacity-50" 
                                        style={{ height: `${val * 25}%` }}
                                        title={`${val.toFixed(2)} Mbps`}
                                      ></div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div className="mt-2 grid grid-cols-2 text-xs text-gray-600">
                                <div>
                                  <span className="inline-block w-3 h-3 bg-blue-500 mr-1"></span> Upload: Current: 61.71 k | Maximum: 729.41 k
                                </div>
                                <div>
                                  <span className="inline-block w-3 h-3 bg-red-500 opacity-50 mr-1"></span> Download: Current: 847.20 k | Maximum: 2.37 M
                                </div>
                              </div>
                            </div>
                            
                            <div className="bg-gray-50 p-4 rounded">
                              <h4 className="text-sm font-medium mb-2">gpon-onu_1/1/1:19 weekly signal</h4>
                              <div className="h-40 relative">
                                {/* Simulated signal graph */}
                                <div className="absolute top-0 left-0 right-0 h-full flex items-start">
                                  {Array(10).fill(0).map((_, i) => (
                                    <div key={`signal-${i}`} className="flex-1 mx-px h-full flex flex-col justify-between">
                                      <div className="border-t border-gray-200 w-full"></div>
                                      <div className="border-t border-gray-200 w-full"></div>
                                      <div className="border-t border-gray-200 w-full"></div>
                                    </div>
                                  ))}
                                </div>
                                <div className="absolute top-[40%] left-0 right-0 h-[20%] flex items-center">
                                  <div className="w-full h-[2px] bg-orange-500 z-10"></div>
                                </div>
                              </div>
                              <div className="mt-2 grid grid-cols-1 text-xs text-gray-600">
                                <div>
                                  <span className="inline-block w-3 h-3 bg-orange-500 mr-1"></span> 1310nm OLT Rx for ONU | Current: -30.19 | Maximum: -29.96
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="font-medium mb-2">Speed profiles</h3>
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <h4 className="text-sm font-medium">Download</h4>
                              <div className="mt-2">1G</div>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Upload</h4>
                              <div className="mt-2">1G</div>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium">Action</h4>
                              <div className="mt-2">
                                <Button variant="outline" size="sm" className="flex items-center text-blue-500">
                                  <RefreshCw className="mr-1 h-3 w-3" /> Configure
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-1">
              <Card className="mb-6">
                <CardContent className="pt-6">
                  <div className="grid grid-cols-1 gap-2">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={handleGetStatus}
                    >
                      Get status
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={handleShowConfig}
                    >
                      Show running config
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start" 
                      onClick={handleSWInfo}
                    >
                      SW info
                    </Button>
                    <Button 
                      variant="secondary" 
                      className="w-full justify-start bg-green-500 hover:bg-green-600 text-white" 
                      onClick={handleLiveAccess}
                    >
                      LIVE!
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">ONU Device</CardTitle>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="flex justify-center">
                    <img 
                      src="/assets/onu-device.png" 
                      alt="ONU Device" 
                      className="max-w-full h-auto"
                      onError={(e) => {
                        // Fallback if image not found
                        e.currentTarget.src = "https://placehold.co/300x150/e2e8f0/475569?text=ONU+Device";
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}