import { useState } from "react";
import { Link, Route, Switch, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/header";
import { Loader2, Plus, Download, Trash2, Settings, Edit } from "lucide-react";

// Import settings components
import OltTypesSettings from "@/components/settings/olt-types";
import OnuTypesSettings from "@/components/settings/onu-types";
import VlansSettings from "@/components/settings/vlans";
import BillingSettings from "@/components/settings/billing";
import UsersSettings from "@/components/settings/users";
import SystemSettings from "@/components/settings/system-settings";

export default function SettingsPage() {
  const [, navigate] = useLocation();
  const [activePath, setActivePath] = useLocation();
  const { toast } = useToast();
  
  // Determine active tab based on current location
  const getActiveTab = () => {
    if (activePath.includes("olt-types")) return "olt-types";
    if (activePath.includes("onu-types")) return "onu-types";
    if (activePath.includes("vlans")) return "vlans";

    if (activePath.includes("billing")) return "billing";
    if (activePath.includes("users")) return "users";
    if (activePath.includes("system")) return "system";
    return "olt-types"; // Default tab
  };

  const handleTabChange = (value: string) => {
    navigate(`/settings/${value}`);
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-4">
        <h1 className="text-2xl font-bold mb-6">Settings</h1>
        
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>System Configuration</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs 
                value={getActiveTab()} 
                onValueChange={handleTabChange}
                className="w-full"
              >
                <TabsList className="mb-4 w-full justify-start overflow-x-auto flex-nowrap">
                  <TabsTrigger value="olt-types">OLT Types</TabsTrigger>
                  <TabsTrigger value="onu-types">ONU Types</TabsTrigger>
                  <TabsTrigger value="vlans">VLANs</TabsTrigger>
                  <TabsTrigger value="billing">Billing</TabsTrigger>
                  <TabsTrigger value="users">Users</TabsTrigger>
                  <TabsTrigger value="system">System Settings</TabsTrigger>
                </TabsList>

                <Switch>
                  <Route path="/settings/olt-types">
                    <OltTypesSettings />
                  </Route>
                  <Route path="/settings/onu-types">
                    <OnuTypesSettings />
                  </Route>
                  <Route path="/settings/vlans">
                    <VlansSettings />
                  </Route>
                  <Route path="/settings/billing">
                    <BillingSettings />
                  </Route>
                  <Route path="/settings/users">
                    <UsersSettings />
                  </Route>
                  <Route path="/settings/system">
                    <SystemSettings />
                  </Route>
                  <Route path="/settings/:others*">
                    {/* Redirect to OLT Types if no specific route matches */}
                    <div className="py-4">
                      <Loader2 className="h-8 w-8 animate-spin mx-auto" />
                      <p className="text-center mt-2">Redirecting...</p>
                    </div>
                  </Route>
                </Switch>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}