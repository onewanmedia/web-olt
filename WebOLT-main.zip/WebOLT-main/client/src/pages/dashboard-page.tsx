import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import StatusCard from "@/components/status-card";
import OnuTable from "@/components/onu-table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Search, FilterIcon, RefreshCw } from "lucide-react";
import { Label } from "@/components/ui/label";

export default function DashboardPage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    olt: "Any",
    board: "Any",
    port: "Any",
    zone: "Any",
    odb: "Any",
    onuType: "Any",
    profile: "Any",
  });

  // Fetch ONU devices
  const { data: onuDevices = [], isLoading: isLoadingOnu } = useQuery({
    queryKey: ["/api/onu-devices"],
    onError: (err) => {
      console.error("Failed to fetch ONU devices:", err);
    },
  });

  // Stats calculation
  const stats = {
    waitingAuthorization: 0,
    online: onuDevices.filter(device => device.status === "online").length,
    offline: onuDevices.filter(device => device.status === "offline").length,
    lowSignals: 3,  // Placeholder - would need real signal strength data
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleFilterChange = (field: string, value: string) => {
    setFilters({
      ...filters,
      [field]: value,
    });
  };

  const resetFilters = () => {
    setFilters({
      olt: "Any",
      board: "Any",
      port: "Any",
      zone: "Any",
      odb: "Any",
      onuType: "Any",
      profile: "Any",
    });
    setSearchQuery("");
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto px-4 py-6">
          {/* Dashboard Status Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <StatusCard 
              title="Waiting authorization"
              value={stats.waitingAuthorization}
              icon={<FilterIcon className="h-6 w-6" />}
              color="primary"
              details={[
                { label: "D", value: 0 },
                { label: "Resync", value: 0 },
                { label: "New", value: 0 },
              ]}
            />
            
            <StatusCard 
              title="Online"
              value={stats.online}
              icon={<span className="relative rounded-full h-3 w-3 bg-green-500" />}
              color="success"
              details={[
                { label: "Total authorized", value: stats.online + stats.offline },
              ]}
            />
            
            <StatusCard 
              title="Total offline"
              value={stats.offline}
              icon={<span className="relative rounded-full h-3 w-3 bg-red-500" />}
              color="gray"
              details={[
                { label: "PwrFail", value: 0 },
                { label: "LoS", value: 0 },
                { label: "N/A", value: stats.offline },
              ]}
            />
            
            <StatusCard 
              title="Low signals"
              value={stats.lowSignals}
              icon={<span className="relative rounded-full h-3 w-3 bg-yellow-500" />}
              color="warning"
              details={[
                { label: "Warning", value: stats.lowSignals },
                { label: "Critical", value: 0 },
              ]}
            />
          </div>

          {/* Search and Filter Controls */}
          <Card className="p-4 mb-6">
            <div className="grid grid-cols-1 lg:grid-cols-7 gap-4 mb-4">
              <div className="lg:col-span-2">
                <Label className="block text-sm font-medium mb-1">Search</Label>
                <div className="flex">
                  <Input
                    type="text"
                    placeholder="SN, IP, name, address, phone"
                    value={searchQuery}
                    onChange={handleSearchChange}
                    className="rounded-l-md"
                  />
                  <Button variant="default" className="rounded-l-none">
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div>
                <Label className="block text-sm font-medium mb-1">OLT</Label>
                <Select
                  value={filters.olt}
                  onValueChange={(value) => handleFilterChange("olt", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="block text-sm font-medium mb-1">Board</Label>
                <Select
                  value={filters.board}
                  onValueChange={(value) => handleFilterChange("board", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="block text-sm font-medium mb-1">Port</Label>
                <Select
                  value={filters.port}
                  onValueChange={(value) => handleFilterChange("port", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="block text-sm font-medium mb-1">Zone</Label>
                <Select
                  value={filters.zone}
                  onValueChange={(value) => handleFilterChange("zone", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                    <SelectItem value="Zone 1">Zone 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="block text-sm font-medium mb-1">ODB</Label>
                <Select
                  value={filters.odb}
                  onValueChange={(value) => handleFilterChange("odb", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                    <SelectItem value="None">None</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label className="block text-sm font-medium mb-1">ONU type</Label>
                <Select
                  value={filters.onuType}
                  onValueChange={(value) => handleFilterChange("onuType", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                    <SelectItem value="ZXHN-F670">ZXHN-F670</SelectItem>
                    <SelectItem value="ZXHN-F609">ZXHN-F609</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="block text-sm font-medium mb-1">Profile</Label>
                <Select
                  value={filters.profile}
                  onValueChange={(value) => handleFilterChange("profile", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Any">Any</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="col-span-1 md:col-span-2 flex items-end space-x-2">
                <Button className="flex items-center">
                  <FilterIcon className="h-4 w-4 mr-2" /> Apply Filters
                </Button>
                <Button variant="outline" onClick={resetFilters} className="flex items-center">
                  <RefreshCw className="h-4 w-4 mr-2" /> Reset
                </Button>
              </div>
            </div>
          </Card>

          {/* ONU Table */}
          <OnuTable devices={onuDevices} isLoading={isLoadingOnu} />
        </div>
      </main>
    </div>
  );
}
