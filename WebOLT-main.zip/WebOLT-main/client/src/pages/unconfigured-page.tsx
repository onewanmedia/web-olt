import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Search, RefreshCw, Plus } from "lucide-react";
import { OnuDevice } from "@shared/schema";
import { useLocation } from "wouter";

export default function UnconfiguredPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch unconfigured ONU devices
  const { data: unconfiguredDevices = [], isLoading, refetch } = useQuery<OnuDevice[]>({
    queryKey: ["/api/onu-devices/unconfigured"],
  });

  // Filter devices by search query
  const filteredDevices = unconfiguredDevices.filter(device => 
    device.serialNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    device.oltIndex.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (device.type && device.type.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleConfigureDevice = (deviceId: number) => {
    // In a real implementation, this would navigate to a configuration page
    // or open a configuration modal
    console.log(`Configure device ${deviceId}`);
  };

  // Card view for small devices
  const renderCardView = () => {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4">
        {filteredDevices.length === 0 ? (
          <div className="col-span-full text-center py-6 text-gray-500">
            No unconfigured ONU devices found
          </div>
        ) : (
          filteredDevices.map((device) => (
            <div key={device.id} className="bg-white border rounded-md shadow-sm p-4">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <Badge variant="outline" className="bg-yellow-100 border-yellow-200 text-yellow-800">
                    Unconfigured
                  </Badge>
                </div>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => handleConfigureDevice(device.id)}
                  className="ml-2"
                >
                  <Plus className="h-4 w-4 mr-1" /> Configure
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-gray-500">SN/MAC:</div>
                <div>{device.serialNumber}</div>
                
                <div className="text-gray-500">ONU:</div>
                <div>{device.oltIndex}</div>
                
                <div className="text-gray-500">Model:</div>
                <div>{device.type || "Unknown"}</div>
                
                <div className="text-gray-500">Signal:</div>
                <div>
                  {device.signal === 'good' ? (
                    <span className="text-green-500">Good</span>
                  ) : (
                    <span className="text-gray-400">None</span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen bg-background">
        <Header />
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto px-4 py-6">
            <div className="bg-white rounded-md shadow-md p-8 text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
              <p className="text-gray-500">Loading unconfigured ONU devices...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto px-4 py-6">
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">ONU UNCONFIGURED</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
                <div className="w-full md:w-1/3">
                  <div className="flex">
                    <Input
                      type="text"
                      placeholder="Search by SN, ONU index, or model"
                      value={searchQuery}
                      onChange={handleSearchChange}
                      className="rounded-l-md"
                    />
                    <Button variant="default" className="rounded-l-none">
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => refetch()} 
                  className="flex items-center"
                >
                  <RefreshCw className="h-4 w-4 mr-2" /> Refresh
                </Button>
              </div>

              {/* Table for larger screens */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>No</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>ONU Index</TableHead>
                      <TableHead>S/N</TableHead>
                      <TableHead>Model</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDevices.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                          No data available in table
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredDevices.map((device, index) => (
                        <TableRow key={device.id}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleConfigureDevice(device.id)}
                              className="flex items-center"
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Configure
                            </Button>
                          </TableCell>
                          <TableCell>{device.oltIndex}</TableCell>
                          <TableCell>{device.serialNumber}</TableCell>
                          <TableCell>{device.type || "Unknown"}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-yellow-100 border-yellow-200 text-yellow-800">
                              Unconfigured
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Card view for mobile screens */}
              <div className="md:hidden">
                {renderCardView()}
              </div>
              
              <div className="flex justify-between items-center mt-4 text-sm text-gray-500">
                <div>
                  Showing {filteredDevices.length} of {unconfiguredDevices.length} devices
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled={true}>Previous</Button>
                  <Button variant="outline" size="sm" disabled={true}>Next</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}