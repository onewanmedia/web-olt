import { useState } from "react";
import Header from "@/components/header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";

export default function RegisterOnuPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("zte");
  const [servicePorts, setServicePorts] = useState<Array<{id: string, vport: string, userVlan: string, vlanId: string}>>([]);
  const [services, setServices] = useState<Array<{id: string, name: string, gemPort: string, vlanId: string}>>([]);
  const [ethPorts, setEthPorts] = useState<Array<{port: string, tag: string, vlanId: string, dhcp: string}>>([]);
  const [wifiConfigs, setWifiConfigs] = useState<Array<{interface: string, tag: string, vlanId: string, security: string, status: string, ssid: string, password: string}>>([]);

  // Query to get OLT devices for dropdown
  const { data: oltDevices } = useQuery({
    queryKey: ['/api/olt-devices'],
  });

  // Form fields state
  const [formData, setFormData] = useState({
    // Basic ONU Information
    oltDeviceId: "",
    gponPort1: "",
    gponPort2: "",
    gponPort3: "",
    onuId: "",
    onuType: "",
    serialNumber: "",
    name: "",
    description: "",
    
    // Traffic & Service Configuration
    tcontId: "",
    tcontName: "PPPOE",
    profile: "1G",
    gemPortId: "",
    gemPortName: "PPPOE",
    veipModeHybrid: "disable",

    // WAN Configuration
    wanId: "1",
    wanMode: "PPPoE",
    username: "",
    password: "",
    host: "1",
    vlanProfile: "PPPOE",
    wanService: "internet",
    securityId: "212",
    securityState: "Enable",
    securityMode: "Forward",
    securityProtocol: "Web"
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Add a new service port row
  const handleAddServicePort = () => {
    const newId = `sp-${Date.now()}`;
    setServicePorts(prev => [...prev, {
      id: newId,
      vport: "",
      userVlan: "",
      vlanId: ""
    }]);
  };

  // Remove a service port row
  const handleRemoveServicePort = (id: string) => {
    setServicePorts(prev => prev.filter(port => port.id !== id));
  };

  // Add a new service row
  const handleAddService = () => {
    const newId = `svc-${Date.now()}`;
    setServices(prev => [...prev, {
      id: newId,
      name: "",
      gemPort: "",
      vlanId: ""
    }]);
  };

  // Remove a service row
  const handleRemoveService = (id: string) => {
    setServices(prev => prev.filter(service => service.id !== id));
  };

  // Add a new ETH port row
  const handleAddEthPort = () => {
    setEthPorts(prev => [...prev, {
      port: "eth_0/1",
      tag: "Tag",
      vlanId: "",
      dhcp: "DHCP from Internet"
    }]);
  };

  // Remove an ETH port row
  const handleRemoveEthPort = (index: number) => {
    setEthPorts(prev => prev.filter((_, i) => i !== index));
  };

  // Add a new WiFi configuration row
  const handleAddWifiConfig = () => {
    setWifiConfigs(prev => [...prev, {
      interface: "wifi_0/1",
      tag: "Tag",
      vlanId: "",
      security: "WPA2 Password",
      status: "Unlock",
      ssid: "",
      password: ""
    }]);
  };

  // Remove a WiFi configuration row
  const handleRemoveWifiConfig = (index: number) => {
    setWifiConfigs(prev => prev.filter((_, i) => i !== index));
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log("Form Data:", formData);
    console.log("Service Ports:", servicePorts);
    console.log("Services:", services);
    console.log("ETH Ports:", ethPorts);
    console.log("WiFi Configs:", wifiConfigs);
    
    toast({
      title: "ONU Registration",
      description: "Registration submitted successfully. Processing command...",
    });

    // Here you would typically send this data to your API
    // registerMutation.mutate();
  };

  // Handler for "Check Unconfigured ONUs" button
  const handleCheckUnconfigured = () => {
    toast({
      title: "Scanning for ONUs",
      description: "Scanning the network for unconfigured ONUs...",
    });
    // In a real implementation, this would trigger an API call to scan for ONUs
  };

  // Handler for "Preview Commands" button
  const handlePreviewCommands = () => {
    toast({
      title: "Command Preview",
      description: "Generated commands for ONU registration will be shown here.",
    });
    // This would generate and display the CLI commands that would be sent to the OLT
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-4">
        <h1 className="text-2xl font-bold mb-4">Register New ONU</h1>
        
        <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
          <TabsList className="mb-4">
            <TabsTrigger value="zte">ZTE ONU</TabsTrigger>
            <TabsTrigger value="non-zte">Non-ZTE ONU</TabsTrigger>
          </TabsList>
          
          <TabsContent value="zte">
            <Card>
              <CardHeader className="bg-slate-50 pb-3 flex justify-between items-center flex-row">
                <CardTitle className="text-lg">ZTE ONU Registration</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleCheckUnconfigured}>
                    Check Unconfigured ONUs
                  </Button>
                  <Button variant="outline" onClick={handlePreviewCommands}>
                    Preview Commands
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-0">
                <form onSubmit={handleSubmit}>
                  {/* Basic ONU Information Section */}
                  <div className="bg-blue-600 text-white p-3 font-medium">
                    Basic ONU Information
                  </div>
                  <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-1">GPON Port</label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="1"
                          className="w-full"
                          name="gponPort1"
                          value={formData.gponPort1}
                          onChange={handleInputChange}
                        />
                        <Input
                          placeholder="1"
                          className="w-full"
                          name="gponPort2"
                          value={formData.gponPort2}
                          onChange={handleInputChange}
                        />
                        <Input
                          placeholder="1"
                          className="w-full"
                          name="gponPort3"
                          value={formData.gponPort3}
                          onChange={handleInputChange}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">ONU ID</label>
                      <Input
                        placeholder="e.g. 10"
                        name="onuId"
                        value={formData.onuId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">ONU Type</label>
                      <Input
                        placeholder="e.g. ZXH-F670"
                        name="onuType"
                        value={formData.onuType}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Serial Number</label>
                      <Input
                        placeholder="e.g. ZTEGC1234567"
                        name="serialNumber"
                        value={formData.serialNumber}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Name</label>
                      <Input
                        placeholder="e.g. Customer Name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Description</label>
                      <Input
                        placeholder="e.g. Customer Address"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  {/* Traffic & Service Configuration Section */}
                  <div className="bg-blue-600 text-white p-3 font-medium">
                    Traffic & Service Configuration
                  </div>
                  <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-1">T-CONT ID</label>
                      <Input
                        placeholder="e.g. 1"
                        name="tcontId"
                        value={formData.tcontId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">T-CONT Name</label>
                      <Input
                        placeholder="PPPOE"
                        name="tcontName"
                        value={formData.tcontName}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Profile</label>
                      <Select 
                        value={formData.profile} 
                        onValueChange={(value) => handleSelectChange("profile", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1G">1G</SelectItem>
                          <SelectItem value="100M">100M</SelectItem>
                          <SelectItem value="50M">50M</SelectItem>
                          <SelectItem value="20M">20M</SelectItem>
                          <SelectItem value="10M">10M</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">GEM Port ID</label>
                      <Input
                        placeholder="1"
                        name="gemPortId"
                        value={formData.gemPortId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">GEM Port Name</label>
                      <Input
                        placeholder="PPPOE"
                        name="gemPortName"
                        value={formData.gemPortName}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  {/* Service Ports Section */}
                  <div className="p-6">
                    <label className="block text-sm font-medium mb-4">Service Ports</label>
                    {servicePorts.map(port => (
                      <div key={port.id} className="flex gap-2 mb-2 items-center">
                        <Input 
                          placeholder="Service Port ID" 
                          className="flex-1"
                          value={port.vport}
                          onChange={(e) => {
                            const updatedPorts = servicePorts.map(p => 
                              p.id === port.id ? {...p, vport: e.target.value} : p
                            );
                            setServicePorts(updatedPorts);
                          }}
                        />
                        <Input 
                          placeholder="VPort" 
                          className="flex-1"
                          value={port.userVlan}
                          onChange={(e) => {
                            const updatedPorts = servicePorts.map(p => 
                              p.id === port.id ? {...p, userVlan: e.target.value} : p
                            );
                            setServicePorts(updatedPorts);
                          }}
                        />
                        <Input 
                          placeholder="User VLAN" 
                          className="flex-1"
                          value={port.vlanId}
                          onChange={(e) => {
                            const updatedPorts = servicePorts.map(p => 
                              p.id === port.id ? {...p, vlanId: e.target.value} : p
                            );
                            setServicePorts(updatedPorts);
                          }}
                        />
                        <button
                          type="button"
                          className="bg-red-500 text-white p-2 rounded-md hover:bg-red-600"
                          onClick={() => handleRemoveServicePort(port.id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    <Button 
                      type="button" 
                      className="mt-2" 
                      variant="outline" 
                      size="sm"
                      onClick={handleAddServicePort}
                    >
                      Add Service Port
                    </Button>
                  </div>
                  
                  {/* Services Section */}
                  <div className="p-4">
                    <label className="block text-sm font-medium mb-2">Services</label>
                    {services.map(service => (
                      <div key={service.id} className="flex gap-2 mb-2 items-center">
                        <Input 
                          placeholder="Service Name" 
                          className="flex-1"
                          value={service.name}
                          onChange={(e) => {
                            const updatedServices = services.map(s => 
                              s.id === service.id ? {...s, name: e.target.value} : s
                            );
                            setServices(updatedServices);
                          }}
                        />
                        <Input 
                          placeholder="GEM Port" 
                          className="flex-1"
                          value={service.gemPort}
                          onChange={(e) => {
                            const updatedServices = services.map(s => 
                              s.id === service.id ? {...s, gemPort: e.target.value} : s
                            );
                            setServices(updatedServices);
                          }}
                        />
                        <Input 
                          placeholder="VLAN ID" 
                          className="flex-1"
                          value={service.vlanId}
                          onChange={(e) => {
                            const updatedServices = services.map(s => 
                              s.id === service.id ? {...s, vlanId: e.target.value} : s
                            );
                            setServices(updatedServices);
                          }}
                        />
                        <button
                          type="button"
                          className="bg-red-500 text-white p-2 rounded-md hover:bg-red-600"
                          onClick={() => handleRemoveService(service.id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    <Button 
                      type="button" 
                      className="mt-2" 
                      variant="outline" 
                      size="sm"
                      onClick={handleAddService}
                    >
                      Add Service
                    </Button>
                  </div>
                  
                  {/* WAN Configuration Section */}
                  <div className="bg-blue-600 text-white p-3 font-medium">
                    WAN Configuration
                  </div>
                  <div className="p-4 grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">WAN ID</label>
                      <Input
                        placeholder="1"
                        name="wanId"
                        value={formData.wanId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">WAN Mode</label>
                      <Select 
                        value={formData.wanMode} 
                        onValueChange={(value) => handleSelectChange("wanMode", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="PPPoE">PPPoE</SelectItem>
                          <SelectItem value="IPoE">IPoE</SelectItem>
                          <SelectItem value="Bridge">Bridge</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Username</label>
                      <Input
                        placeholder="PPPoE Username"
                        name="username"
                        value={formData.username}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Password</label>
                      <Input
                        type="password"
                        placeholder="PPPoE Password"
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Host</label>
                      <Input
                        placeholder="1"
                        name="host"
                        value={formData.host}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">VLAN Profile</label>
                      <Input
                        placeholder="PPPOE"
                        name="vlanProfile"
                        value={formData.vlanProfile}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">WAN Service</label>
                      <Input
                        placeholder="internet"
                        name="wanService"
                        value={formData.wanService}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  {/* Security Management Section */}
                  <div className="p-4">
                    <label className="block text-sm font-medium mb-2">Security Management</label>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Security ID</label>
                        <Input
                          placeholder="212"
                          name="securityId"
                          value={formData.securityId}
                          onChange={handleInputChange}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">State</label>
                        <Select 
                          value={formData.securityState} 
                          onValueChange={(value) => handleSelectChange("securityState", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Enable">Enable</SelectItem>
                            <SelectItem value="Disable">Disable</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">Mode</label>
                        <Select 
                          value={formData.securityMode} 
                          onValueChange={(value) => handleSelectChange("securityMode", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Forward">Forward</SelectItem>
                            <SelectItem value="Block">Block</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-1">Protocol</label>
                        <Select 
                          value={formData.securityProtocol} 
                          onValueChange={(value) => handleSelectChange("securityProtocol", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Web">Web</SelectItem>
                            <SelectItem value="Telnet">Telnet</SelectItem>
                            <SelectItem value="SSH">SSH</SelectItem>
                            <SelectItem value="ICMP">ICMP</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  
                  {/* Port Configuration Section */}
                  <div className="bg-blue-600 text-white p-3 font-medium">
                    Port Configuration
                  </div>
                  
                  {/* ETH Ports VLAN Configuration */}
                  <div className="p-4">
                    <label className="block text-sm font-medium mb-2">ETH Ports VLAN Configuration</label>
                    {ethPorts.map((port, index) => (
                      <div key={index} className="flex gap-2 mb-2 items-center">
                        <Select 
                          value={port.port} 
                          onValueChange={(value) => {
                            const updatedPorts = [...ethPorts];
                            updatedPorts[index] = {...updatedPorts[index], port: value};
                            setEthPorts(updatedPorts);
                          }}
                        >
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Select Port" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="eth_0/1">eth_0/1</SelectItem>
                            <SelectItem value="eth_0/2">eth_0/2</SelectItem>
                            <SelectItem value="eth_0/3">eth_0/3</SelectItem>
                            <SelectItem value="eth_0/4">eth_0/4</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <Select 
                          value={port.tag} 
                          onValueChange={(value) => {
                            const updatedPorts = [...ethPorts];
                            updatedPorts[index] = {...updatedPorts[index], tag: value};
                            setEthPorts(updatedPorts);
                          }}
                        >
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Tag" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Tag">Tag</SelectItem>
                            <SelectItem value="Untag">Untag</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <Input 
                          placeholder="VLAN ID" 
                          className="flex-1"
                          value={port.vlanId}
                          onChange={(e) => {
                            const updatedPorts = [...ethPorts];
                            updatedPorts[index] = {...updatedPorts[index], vlanId: e.target.value};
                            setEthPorts(updatedPorts);
                          }}
                        />
                        
                        <Select 
                          value={port.dhcp} 
                          onValueChange={(value) => {
                            const updatedPorts = [...ethPorts];
                            updatedPorts[index] = {...updatedPorts[index], dhcp: value};
                            setEthPorts(updatedPorts);
                          }}
                        >
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="DHCP" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="No DHCP Config">No DHCP Config</SelectItem>
                            <SelectItem value="DHCP from ONU">DHCP from ONU</SelectItem>
                            <SelectItem value="DHCP from Internet">DHCP from Internet</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <button
                          type="button"
                          className="bg-red-500 text-white p-2 rounded-md hover:bg-red-600"
                          onClick={() => handleRemoveEthPort(index)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    <Button 
                      type="button" 
                      className="mt-2" 
                      variant="outline" 
                      size="sm"
                      onClick={handleAddEthPort}
                    >
                      Add ETH Port
                    </Button>
                  </div>
                  
                  {/* WiFi Configuration */}
                  <div className="p-4">
                    <label className="block text-sm font-medium mb-2">WiFi Configuration</label>
                    {wifiConfigs.map((config, index) => (
                      <div key={index} className="mb-4 border p-3 rounded-lg">
                        <div className="flex gap-2 mb-2 items-center">
                          <Select 
                            value={config.interface} 
                            onValueChange={(value) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], interface: value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          >
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Select Interface" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="wifi_0/1">wifi_0/1</SelectItem>
                              <SelectItem value="wifi_0/2">wifi_0/2</SelectItem>
                              <SelectItem value="wifi_0/3">wifi_0/3</SelectItem>
                              <SelectItem value="wifi_0/4">wifi_0/4</SelectItem>
                              <SelectItem value="wifi_0/5">wifi_0/5</SelectItem>
                              <SelectItem value="wifi_0/6">wifi_0/6</SelectItem>
                              <SelectItem value="wifi_0/7">wifi_0/7</SelectItem>
                              <SelectItem value="wifi_0/8">wifi_0/8</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          <Select 
                            value={config.tag} 
                            onValueChange={(value) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], tag: value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          >
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Tag" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Tag">Tag</SelectItem>
                              <SelectItem value="Untag">Untag</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          <Input 
                            placeholder="VLAN ID" 
                            className="flex-1"
                            value={config.vlanId}
                            onChange={(e) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], vlanId: e.target.value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          />
                          
                          <Select 
                            value={config.status} 
                            onValueChange={(value) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], status: value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          >
                            <SelectTrigger className="w-36">
                              <SelectValue placeholder="Status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Unlock">Unlock</SelectItem>
                              <SelectItem value="Lock">Lock</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          <button
                            type="button"
                            className="bg-red-500 text-white p-2 rounded-md hover:bg-red-600"
                            onClick={() => handleRemoveWifiConfig(index)}
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                        
                        <div className="flex gap-2 mt-2">
                          <Input 
                            placeholder="SSID Name" 
                            className="flex-1"
                            value={config.ssid}
                            onChange={(e) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], ssid: e.target.value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          />
                          
                          <Select 
                            value={config.security} 
                            onValueChange={(value) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], security: value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          >
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder="Security" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="WPA Password">WPA Password</SelectItem>
                              <SelectItem value="WPA2 Password">WPA2 Password</SelectItem>
                              <SelectItem value="WPA/WPA2 Password">WPA/WPA2 Password</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          <Input 
                            placeholder="WiFi Password" 
                            className="flex-1"
                            value={config.password}
                            onChange={(e) => {
                              const updatedConfigs = [...wifiConfigs];
                              updatedConfigs[index] = {...updatedConfigs[index], password: e.target.value};
                              setWifiConfigs(updatedConfigs);
                            }}
                          />
                        </div>
                        <div className="mt-2 text-xs text-gray-500">
                          {config.interface} - {config.status === "Lock" ? "disabled" : "enabled"} - {config.security || "WPA2 Password"}
                        </div>
                      </div>
                    ))}
                    <Button 
                      type="button" 
                      className="mt-2" 
                      variant="outline" 
                      size="sm"
                      onClick={handleAddWifiConfig}
                    >
                      Add WiFi Configuration
                    </Button>
                  </div>
                  
                  <div className="p-4">
                    <Button type="submit" className="mr-2">Register ZTE ONU</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="non-zte">
            <Card>
              <CardHeader className="bg-slate-50 pb-3 flex justify-between items-center flex-row">
                <CardTitle className="text-lg">Non-ZTE ONU Registration</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleCheckUnconfigured}>
                    Check Unconfigured ONUs
                  </Button>
                  <Button variant="outline" onClick={handlePreviewCommands}>
                    Preview Commands
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-0">
                <form onSubmit={handleSubmit}>
                  {/* Basic ONU Information Section */}
                  <div className="bg-blue-600 text-white p-3 font-medium">
                    Basic ONU Information
                  </div>
                  <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-1">GPON Port</label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="1"
                          className="w-full"
                          name="gponPort1"
                          value={formData.gponPort1}
                          onChange={handleInputChange}
                        />
                        <Input
                          placeholder="1"
                          className="w-full"
                          name="gponPort2"
                          value={formData.gponPort2}
                          onChange={handleInputChange}
                        />
                        <Input
                          placeholder="1"
                          className="w-full"
                          name="gponPort3"
                          value={formData.gponPort3}
                          onChange={handleInputChange}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">ONU ID</label>
                      <Input
                        placeholder="e.g. 10"
                        name="onuId"
                        value={formData.onuId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">ONU Type</label>
                      <Input
                        placeholder="e.g. Huawei HG8245H"
                        name="onuType"
                        value={formData.onuType}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Serial Number</label>
                      <Input
                        placeholder="e.g. HWTC1234567"
                        name="serialNumber"
                        value={formData.serialNumber}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Name</label>
                      <Input
                        placeholder="e.g. Customer Name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Description</label>
                      <Input
                        placeholder="e.g. Customer Address"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                  
                  {/* Traffic & Service Configuration Section */}
                  <div className="bg-blue-600 text-white p-3 font-medium">
                    Traffic & Service Configuration
                  </div>
                  <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-1">T-CONT ID</label>
                      <Input
                        placeholder="e.g. 1"
                        name="tcontId"
                        value={formData.tcontId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">T-CONT Name</label>
                      <Input
                        placeholder="PPPOE"
                        name="tcontName"
                        value={formData.tcontName}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Profile</label>
                      <Select 
                        value={formData.profile} 
                        onValueChange={(value) => handleSelectChange("profile", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1G">1G</SelectItem>
                          <SelectItem value="100M">100M</SelectItem>
                          <SelectItem value="50M">50M</SelectItem>
                          <SelectItem value="20M">20M</SelectItem>
                          <SelectItem value="10M">10M</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">GEM Port ID</label>
                      <Input
                        placeholder="1"
                        name="gemPortId"
                        value={formData.gemPortId}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">GEM Port Name</label>
                      <Input
                        placeholder="PPPOE"
                        name="gemPortName"
                        value={formData.gemPortName}
                        onChange={handleInputChange}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">VLAN port veip_1 mode hybrid</label>
                      <Select
                        defaultValue="disable"
                        onValueChange={(value) => handleSelectChange("veipModeHybrid", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="enable">Enable</SelectItem>
                          <SelectItem value="disable">Disable</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {/* Service Ports Section */}
                  <div className="p-6">
                    <label className="block text-sm font-medium mb-4">Service Ports</label>
                    {servicePorts.map(port => (
                      <div key={port.id} className="flex gap-2 mb-2 items-center">
                        <Input 
                          placeholder="Service Port ID" 
                          className="flex-1"
                          value={port.vport}
                          onChange={(e) => {
                            const updatedPorts = servicePorts.map(p => 
                              p.id === port.id ? {...p, vport: e.target.value} : p
                            );
                            setServicePorts(updatedPorts);
                          }}
                        />
                        <Input 
                          placeholder="VPort" 
                          className="flex-1"
                          value={port.userVlan}
                          onChange={(e) => {
                            const updatedPorts = servicePorts.map(p => 
                              p.id === port.id ? {...p, userVlan: e.target.value} : p
                            );
                            setServicePorts(updatedPorts);
                          }}
                        />
                        <Input 
                          placeholder="User VLAN" 
                          className="flex-1"
                          value={port.vlanId}
                          onChange={(e) => {
                            const updatedPorts = servicePorts.map(p => 
                              p.id === port.id ? {...p, vlanId: e.target.value} : p
                            );
                            setServicePorts(updatedPorts);
                          }}
                        />
                        <button
                          type="button"
                          className="bg-red-500 text-white p-2 rounded-md hover:bg-red-600"
                          onClick={() => handleRemoveServicePort(port.id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    <Button 
                      type="button" 
                      className="mt-2" 
                      variant="outline" 
                      size="sm"
                      onClick={handleAddServicePort}
                    >
                      Add Service Port
                    </Button>
                  </div>
                  
                  {/* Services Section */}
                  <div className="p-6">
                    <label className="block text-sm font-medium mb-4">Services</label>
                    {services.map(service => (
                      <div key={service.id} className="flex gap-2 mb-2 items-center">
                        <Input 
                          placeholder="Service Name" 
                          className="flex-1"
                          value={service.name}
                          onChange={(e) => {
                            const updatedServices = services.map(s => 
                              s.id === service.id ? {...s, name: e.target.value} : s
                            );
                            setServices(updatedServices);
                          }}
                        />
                        <Input 
                          placeholder="GEM Port" 
                          className="flex-1"
                          value={service.gemPort}
                          onChange={(e) => {
                            const updatedServices = services.map(s => 
                              s.id === service.id ? {...s, gemPort: e.target.value} : s
                            );
                            setServices(updatedServices);
                          }}
                        />
                        <Input 
                          placeholder="VLAN ID" 
                          className="flex-1"
                          value={service.vlanId}
                          onChange={(e) => {
                            const updatedServices = services.map(s => 
                              s.id === service.id ? {...s, vlanId: e.target.value} : s
                            );
                            setServices(updatedServices);
                          }}
                        />
                        <button
                          type="button"
                          className="bg-red-500 text-white p-2 rounded-md hover:bg-red-600"
                          onClick={() => handleRemoveService(service.id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                    <Button 
                      type="button" 
                      className="mt-2" 
                      variant="outline" 
                      size="sm"
                      onClick={handleAddService}
                    >
                      Add Service
                    </Button>
                  </div>
                  
                  <div className="p-6">
                    <Button type="submit" className="mr-2">Register Non-ZTE ONU</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        {/* Unconfigured ONUs List */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Unconfigured ONUs</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-500">Click "Check Unconfigured ONUs" button to scan for new ONUs.</p>
          </CardContent>
        </Card>
        
        <div className="text-center text-xs text-gray-500 mt-6">
          ZTE OLT Management System v1.0<br />
          Current user: {user?.username} | Last updated: {new Date().toLocaleString()}
        </div>
      </main>
    </div>
  );
}