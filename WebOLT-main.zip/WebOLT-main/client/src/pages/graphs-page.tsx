import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Line } from "recharts";

// Dummy data for uplink traffic graphs
const generateDummyTrafficData = (baseValue: number = 0, variance: number = 10) => {
  return Array.from({ length: 24 }, (_, i) => {
    const timestamp = new Date();
    timestamp.setHours(timestamp.getHours() - 24 + i);
    const time = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const date = timestamp.toLocaleDateString([], { weekday: 'short' });
    const value = Math.max(0, baseValue + Math.random() * variance);
    
    return {
      time: `${date} ${time}`,
      in: Math.round(value * 10) / 10,
      out: Math.round((value / 3) * 10) / 10,
    };
  });
};

const interfaceData = [
  { id: 'gei_1/4/1', name: 'gei_1/4/1', traffic: generateDummyTrafficData(2, 3), maxValue: 1.5 },
  { id: 'gei_1/4/2', name: 'gei_1/4/2', traffic: generateDummyTrafficData(35, 15), maxValue: 62.82 },
  { id: 'gei_1/4/3', name: 'gei_1/4/3', traffic: generateDummyTrafficData(0.4, 0.8), maxValue: 1.2 },
];

export default function GraphsPage() {
  const { user } = useAuth();
  const [selectedOlt, setSelectedOlt] = useState<string>("Any");
  const [activeTab, setActiveTab] = useState<string>("uplink");
  
  // This would typically fetch data from your API
  const { data: oltDevices = [], isLoading: isLoadingOlt } = useQuery({
    queryKey: ["/api/olt-devices"],
  });
  
  const handleRefresh = () => {
    // This would typically refetch the data
    console.log("Refreshing data...");
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto px-4 py-6">
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl flex justify-between items-center">
                <span>TRAFFIC GRAPHS</span>
                <Button 
                  variant="outline" 
                  onClick={handleRefresh} 
                  className="flex items-center"
                >
                  <RefreshCw className="h-4 w-4 mr-2" /> Refresh
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Filter controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                <div>
                  <Label htmlFor="olt-select" className="block text-sm font-medium mb-1">OLTs</Label>
                  <Select value={selectedOlt} onValueChange={setSelectedOlt}>
                    <SelectTrigger className="w-full" id="olt-select">
                      <SelectValue placeholder="Select OLT" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Any">Any</SelectItem>
                      {oltDevices.map((olt: any) => (
                        <SelectItem key={olt.id} value={olt.id.toString()}>
                          {olt.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="block text-sm font-medium mb-1">Graphs for</Label>
                  <div className="w-full flex bg-white border rounded-md">
                    <button 
                      className={`flex-grow text-sm p-2 ${activeTab === 'olt' ? 'bg-primary text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => setActiveTab('olt')}
                    >
                      OLT
                    </button>
                    <button 
                      className={`flex-grow text-sm p-2 ${activeTab === 'uplink' ? 'bg-primary text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => setActiveTab('uplink')}
                    >
                      Uplink
                    </button>
                    <button 
                      className={`flex-grow text-sm p-2 ${activeTab === 'pon' ? 'bg-primary text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => setActiveTab('pon')}
                    >
                      PON
                    </button>
                    <button 
                      className={`flex-grow text-sm p-2 ${activeTab === 'traffic' ? 'bg-primary text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => setActiveTab('traffic')}
                    >
                      Traffic
                    </button>
                    <button 
                      className={`flex-grow text-sm p-2 ${activeTab === 'signal' ? 'bg-primary text-white' : 'hover:bg-gray-100'}`}
                      onClick={() => setActiveTab('signal')}
                    >
                      Signal
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Graphs display */}
              <div className="space-y-8">
                {isLoadingOlt ? (
                  <div className="text-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
                    <p className="text-gray-500">Loading graphs...</p>
                  </div>
                ) : (
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="hidden">
                      <TabsTrigger value="uplink">Uplink</TabsTrigger>
                      <TabsTrigger value="olt">OLT</TabsTrigger>
                      <TabsTrigger value="pon">PON</TabsTrigger>
                      <TabsTrigger value="traffic">Traffic</TabsTrigger>
                      <TabsTrigger value="signal">Signal</TabsTrigger>
                    </TabsList>
                    {/* Only show uplink graphs for now */}
                    <TabsContent value="uplink" className="space-y-8">
                      {interfaceData.map((iface) => (
                        <div key={iface.id} className="space-y-2">
                          <h3 className="text-md font-medium text-gray-700">
                            zte - {iface.name} traffic
                          </h3>
                          <div className="bg-gray-50 p-4 rounded">
                            <div className="h-64">
                              <ResponsiveContainer width="100%" height="100%">
                                <AreaChart
                                  data={iface.traffic}
                                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                  <defs>
                                    <linearGradient id={`colorIn-${iface.id}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor="#3182bd" stopOpacity={0.8} />
                                      <stop offset="95%" stopColor="#3182bd" stopOpacity={0.1} />
                                    </linearGradient>
                                    <linearGradient id={`colorOut-${iface.id}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor="#f28e2c" stopOpacity={0.8} />
                                      <stop offset="95%" stopColor="#f28e2c" stopOpacity={0.1} />
                                    </linearGradient>
                                  </defs>
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis 
                                    dataKey="time" 
                                    tick={{ fontSize: 10 }}
                                    interval="preserveStartEnd"
                                  />
                                  <YAxis 
                                    label={{ 
                                      value: 'bits per second', 
                                      angle: -90, 
                                      position: 'insideLeft',
                                      style: { textAnchor: 'middle', fontSize: 12 }
                                    }} 
                                  />
                                  <Tooltip />
                                  <Legend />
                                  <Area 
                                    type="monotone" 
                                    dataKey="in" 
                                    stroke="#3182bd" 
                                    fillOpacity={1} 
                                    fill={`url(#colorIn-${iface.id})`} 
                                    name="In"
                                  />
                                  <Area 
                                    type="monotone" 
                                    dataKey="out" 
                                    stroke="#f28e2c" 
                                    fillOpacity={1} 
                                    fill={`url(#colorOut-${iface.id})`}
                                    name="Out" 
                                  />
                                </AreaChart>
                              </ResponsiveContainer>
                            </div>
                            <div className="mt-2 text-sm text-gray-600 grid grid-cols-2 gap-4">
                              <div>
                                <span className="inline-block w-3 h-3 bg-blue-500 mr-1"></span> In: Current: {iface.traffic[iface.traffic.length - 1].in.toFixed(2)} M &nbsp; Maximum: {iface.maxValue.toFixed(2)} M
                              </div>
                              <div>
                                <span className="inline-block w-3 h-3 bg-orange-500 mr-1"></span> Out: Current: {(iface.traffic[iface.traffic.length - 1].out).toFixed(2)} M &nbsp; Maximum: {(iface.maxValue / 3).toFixed(2)} M
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </TabsContent>
                    
                    {/* Placeholders for other graph types - would implement similar to above */}
                    <TabsContent value="olt">
                      <div className="text-center py-12 text-gray-500">
                        OLT Graphs will be implemented here
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="pon">
                      <div className="text-center py-12 text-gray-500">
                        PON Graphs will be implemented here
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="traffic">
                      <div className="text-center py-12 text-gray-500">
                        Traffic Graphs will be implemented here
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="signal">
                      <div className="text-center py-12 text-gray-500">
                        Signal Graphs will be implemented here
                      </div>
                    </TabsContent>
                  </Tabs>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}