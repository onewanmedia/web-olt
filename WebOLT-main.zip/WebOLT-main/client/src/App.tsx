import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import ProfilePage from "@/pages/profile-page";
import ConsolePage from "@/pages/console-page";
import UnconfiguredPage from "@/pages/unconfigured-page";
import RegisterOnuPage from "@/pages/register-onu-page";
import GraphsPage from "@/pages/graphs-page";
import OnuDetailPage from "@/pages/onu-detail-page";
import SettingsPage from "@/pages/settings-page";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/console/:id?" component={ConsolePage} />
      <ProtectedRoute path="/unconfigured" component={UnconfiguredPage} />
      <ProtectedRoute path="/register-onu" component={RegisterOnuPage} />
      <ProtectedRoute path="/graphs" component={GraphsPage} />
      <ProtectedRoute path="/onu/:id" component={OnuDetailPage} />
      <ProtectedRoute path="/settings/:tab*" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router />
      <Toaster />
    </AuthProvider>
  );
}

export default App;
