#!/bin/bash

# Script inisialisasi untuk membangun dan menjalankan WebOLT di Docker

# Pastikan memiliki hak akses
chmod +x init.sh

# Salin file konfigurasi lingkungan
if [ ! -f .env ]; then
  echo "Membuat file .env dari .env.example..."
  cp .env.example .env
  echo "File .env telah dibuat. Silakan sesuaikan konfigurasi jika diperlukan."
else
  echo "File .env sudah ada."
fi

# Membangun dan menjalankan container
echo "Membangun dan menjalankan container Docker..."
docker-compose up -d

# Menunggu container database siap
echo "Menunggu container database siap..."
sleep 10

# Menampilkan status container yang berjalan
echo "Container yang berjalan:"
docker-compose ps

echo ""
echo "WebOLT telah berhasil dijalankan!"
echo "Akses aplikasi melalui browser di: http://localhost:5000"
echo ""
echo "Gunakan kredensial default:"
echo "Username: admin"
echo "Password: admin123"
echo ""
echo "Untuk menghentikan aplikasi, jalankan: docker-compose down"