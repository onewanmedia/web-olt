import net from "net";
import { promisify } from "util";
import { EventEmitter } from "events";

export interface TelnetOptions {
  host: string;
  port: number;
  shellPrompt?: string;
  loginPrompt?: string;
  passwordPrompt?: string;
  timeout?: number;
  initialCTRLC?: boolean;
  initialLFCR?: boolean;
  stripShellPrompt?: boolean;
  irs?: string;
  ors?: string;
}

export class TelnetClient extends EventEmitter {
  private socket: net.Socket | null = null;
  private options: TelnetOptions;
  private buffer: string = "";
  private authenticated: boolean = false;
  private busy: boolean = false;
  private timeout: NodeJS.Timeout | null = null;
  private _logging: boolean = false;

  constructor(options: TelnetOptions) {
    super();
    
    this.options = {
      host: options.host,
      port: options.port,
      shellPrompt: options.shellPrompt || /(?:\r\n|\r|\n)(\w+[#>])\s*$/,
      loginPrompt: options.loginPrompt || /(?:\r\n|\r|\n)?login[: ]*$/i,
      passwordPrompt: options.passwordPrompt || /(?:\r\n|\r|\n)?password[: ]*$/i,
      timeout: options.timeout || 30000,
      initialCTRLC: options.initialCTRLC || false,
      initialLFCR: options.initialLFCR || false,
      stripShellPrompt: options.stripShellPrompt || true,
      irs: options.irs || "\r\n",
      ors: options.ors || "\r\n"
    };
  }

  enableLogging() {
    this._logging = true;
  }

  disableLogging() {
    this._logging = false;
  }

  connect() {
    return new Promise<void>((resolve, reject) => {
      this.socket = net.createConnection(
        {
          port: this.options.port,
          host: this.options.host,
          timeout: this.options.timeout
        },
        () => {
          this.log(`Connected to ${this.options.host}:${this.options.port}`);
          
          if (this.options.initialCTRLC) {
            this.socket?.write("\x03");
          }

          if (this.options.initialLFCR) {
            this.socket?.write("\r\n");
          }

          resolve();
        }
      );

      this.socket.on("data", (data) => {
        const dataStr = data.toString();
        this.buffer += dataStr;
        this.log(`Received: ${dataStr}`);
        this.emit("data", dataStr);
        
        if (!this.authenticated) {
          if (this.checkLoginPrompt()) {
            this.emit("login");
          } else if (this.checkPasswordPrompt()) {
            this.emit("password");
          } else if (this.checkShellPrompt()) {
            this.authenticated = true;
            this.emit("authenticated");
          }
        } else if (this.busy && this.checkShellPrompt()) {
          this.busy = false;
          const output = this.processShellOutput();
          this.emit("response", output);
        }
      });

      this.socket.on("error", (error) => {
        this.log(`Socket error: ${error.message}`);
        this.emit("error", error);
        reject(error);
      });

      this.socket.on("close", () => {
        this.log("Connection closed");
        this.emit("close");
      });

      this.socket.on("timeout", () => {
        this.log("Connection timeout");
        this.emit("timeout");
        this.socket?.destroy();
        reject(new Error("Connection timeout"));
      });
    });
  }

  login(username: string, password: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const loginHandler = () => {
        this.write(username);
      };

      const passwordHandler = () => {
        this.write(password);
      };

      const authHandler = () => {
        this.removeListener("login", loginHandler);
        this.removeListener("password", passwordHandler);
        this.removeListener("authenticated", authHandler);
        this.removeListener("error", errorHandler);
        resolve();
      };

      const errorHandler = (error: Error) => {
        this.removeListener("login", loginHandler);
        this.removeListener("password", passwordHandler);
        this.removeListener("authenticated", authHandler);
        this.removeListener("error", errorHandler);
        reject(error);
      };

      this.once("login", loginHandler);
      this.once("password", passwordHandler);
      this.once("authenticated", authHandler);
      this.once("error", errorHandler);

      // Set timeout for login process
      this.timeout = setTimeout(() => {
        this.removeListener("login", loginHandler);
        this.removeListener("password", passwordHandler);
        this.removeListener("authenticated", authHandler);
        this.removeListener("error", errorHandler);
        reject(new Error("Login timeout"));
      }, this.options.timeout);
    }).finally(() => {
      if (this.timeout) {
        clearTimeout(this.timeout);
        this.timeout = null;
      }
    });
  }

  execute(command: string): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!this.socket || !this.authenticated) {
        reject(new Error("Not connected or not authenticated"));
        return;
      }

      if (this.busy) {
        reject(new Error("Client is busy"));
        return;
      }

      this.busy = true;
      this.buffer = "";

      const responseHandler = (output: string) => {
        this.removeListener("response", responseHandler);
        this.removeListener("error", errorHandler);
        resolve(output);
      };

      const errorHandler = (error: Error) => {
        this.removeListener("response", responseHandler);
        this.removeListener("error", errorHandler);
        this.busy = false;
        reject(error);
      };

      this.once("response", responseHandler);
      this.once("error", errorHandler);

      this.write(command);

      // Set timeout for command execution
      this.timeout = setTimeout(() => {
        this.removeListener("response", responseHandler);
        this.removeListener("error", errorHandler);
        this.busy = false;
        reject(new Error("Command execution timeout"));
      }, this.options.timeout);
    }).finally(() => {
      if (this.timeout) {
        clearTimeout(this.timeout);
        this.timeout = null;
      }
    });
  }

  write(data: string) {
    if (!this.socket) {
      throw new Error("Not connected");
    }
    
    this.log(`Sending: ${data}`);
    this.socket.write(data + this.options.ors);
  }

  end() {
    return new Promise<void>((resolve) => {
      if (!this.socket) {
        resolve();
        return;
      }

      this.socket.once("close", () => {
        this.socket = null;
        this.authenticated = false;
        this.busy = false;
        resolve();
      });

      this.socket.end();
    });
  }

  destroy() {
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
      this.authenticated = false;
      this.busy = false;
    }
  }

  private checkLoginPrompt(): boolean {
    if (typeof this.options.loginPrompt === 'string') {
      return this.buffer.includes(this.options.loginPrompt);
    } else if (this.options.loginPrompt instanceof RegExp) {
      return this.options.loginPrompt.test(this.buffer);
    }
    return false;
  }

  private checkPasswordPrompt(): boolean {
    if (typeof this.options.passwordPrompt === 'string') {
      return this.buffer.includes(this.options.passwordPrompt);
    } else if (this.options.passwordPrompt instanceof RegExp) {
      return this.options.passwordPrompt.test(this.buffer);
    }
    return false;
  }

  private checkShellPrompt(): boolean {
    if (typeof this.options.shellPrompt === 'string') {
      return this.buffer.includes(this.options.shellPrompt);
    } else if (this.options.shellPrompt instanceof RegExp) {
      return this.options.shellPrompt.test(this.buffer);
    }
    return false;
  }

  private processShellOutput(): string {
    let output = this.buffer;
    
    // Strip the command echo
    const lines = output.split(/\r\n|\r|\n/);
    if (lines.length > 0) {
      lines.shift(); // Remove the first line (command echo)
    }
    
    // Strip shell prompt if configured
    if (this.options.stripShellPrompt && lines.length > 0) {
      if (typeof this.options.shellPrompt === 'string') {
        if (lines[lines.length - 1].includes(this.options.shellPrompt)) {
          lines.pop();
        }
      } else if (this.options.shellPrompt instanceof RegExp) {
        const lastLine = lines[lines.length - 1];
        if (this.options.shellPrompt.test(lastLine)) {
          lines.pop();
        }
      }
    }
    
    output = lines.join("\n");
    this.buffer = ""; // Clear buffer for next command
    
    return output;
  }

  private log(message: string) {
    if (this._logging) {
      console.log(`[Telnet] ${message}`);
    }
  }
}

export async function createTelnetClient(
  host: string,
  port: number,
  username: string,
  password: string
): Promise<TelnetClient> {
  const client = new TelnetClient({
    host,
    port,
    timeout: 10000,
  });

  try {
    await client.connect();
    await client.login(username, password);
    return client;
  } catch (error) {
    client.destroy();
    throw error;
  }
}
