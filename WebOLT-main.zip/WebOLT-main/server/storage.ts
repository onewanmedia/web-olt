import { users, oltDevices, onuDevices, commandHistory, savedCommands } from "@shared/schema";
import type { 
  User, InsertUser, 
  OltDevice, InsertOltDevice, 
  OnuDevice, InsertOnuDevice,
  CommandHistory, InsertCommandHistory,
  SavedCommand, InsertSavedCommand
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Interface for storage operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // OLT Device methods
  getOltDevices(userId: number): Promise<OltDevice[]>;
  getOltDevice(id: number): Promise<OltDevice | undefined>;
  createOltDevice(device: InsertOltDevice): Promise<OltDevice>;
  updateOltDevice(id: number, device: Partial<OltDevice>): Promise<OltDevice | undefined>;
  deleteOltDevice(id: number): Promise<boolean>;
  
  // ONU Device methods
  getOnuDevices(oltDeviceId?: number): Promise<OnuDevice[]>;
  getOnuDevice(id: number): Promise<OnuDevice | undefined>;
  createOnuDevice(device: InsertOnuDevice): Promise<OnuDevice>;
  updateOnuDevice(id: number, device: Partial<OnuDevice>): Promise<OnuDevice | undefined>;
  deleteOnuDevice(id: number): Promise<boolean>;
  
  // Command History methods
  getCommandHistory(oltDeviceId: number): Promise<CommandHistory[]>;
  createCommandHistory(history: InsertCommandHistory): Promise<CommandHistory>;
  
  // Saved Commands methods
  getSavedCommands(userId: number): Promise<SavedCommand[]>;
  createSavedCommand(command: InsertSavedCommand): Promise<SavedCommand>;
  deleteSavedCommand(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private oltDevices: Map<number, OltDevice>;
  private onuDevices: Map<number, OnuDevice>;
  private commandHistories: Map<number, CommandHistory>;
  private savedCommands: Map<number, SavedCommand>;
  public sessionStore: session.SessionStore;
  private currentUserId: number;
  private currentOltDeviceId: number;
  private currentOnuDeviceId: number;
  private currentCommandHistoryId: number;
  private currentSavedCommandId: number;

  constructor() {
    this.users = new Map();
    this.oltDevices = new Map();
    this.onuDevices = new Map();
    this.commandHistories = new Map();
    this.savedCommands = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    this.currentUserId = 1;
    this.currentOltDeviceId = 1;
    this.currentOnuDeviceId = 1;
    this.currentCommandHistoryId = 1;
    this.currentSavedCommandId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample admin user
    const adminPassword = "admin123"; // This will be hashed when actually used
    this.users.set(this.currentUserId, {
      id: this.currentUserId,
      username: "admin",
      password: "c76c8c5fa52ff0b77d201538f0e96209bb6ae3d87a79a1e0a7191a294d00de3f32a976ec640b1d1d448e7c32e23ec9d74c01e5b79f5e43799c21b1f3d41dfc70.75254aac88d17e591fc3251e28a6c5c9", // Hashed "admin123"
      firstName: "Admin",
      lastName: "User",
      email: "admin@webolt.net",
      registeredAt: new Date(),
      lastLogin: new Date()
    });
    this.currentUserId++;
    
    // Create sample ONU devices based on the design reference
    const sampleOnus: Partial<OnuDevice>[] = [
      {
        name: "wifi ririn",
        serialNumber: "ZTEGC4A397AE",
        oltIndex: "zte gpon-onu 1/1/1:19",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 26",
        type: "ZXHN-F670",
        status: "online"
      },
      {
        name: "wifi qolby",
        serialNumber: "ZTEGCC92C866",
        oltIndex: "zte gpon-onu 1/1/1:18",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 22",
        type: "ZXHN-F609",
        status: "online"
      },
      {
        name: "WARUNG-KLOPO",
        serialNumber: "ZTEGCBDB2581",
        oltIndex: "zte gpon-onu 1/1/1:17",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 25",
        type: "ZXHN-F609",
        status: "online"
      },
      {
        name: "WARUNG-KLOPO",
        serialNumber: "ZTEGCBDF31A0",
        oltIndex: "zte gpon-onu 1/1/1:16",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 25, 300",
        type: "ZXHN-F609",
        status: "online"
      },
      {
        name: "QOLBY",
        serialNumber: "ZTEGC4A39822",
        oltIndex: "zte gpon-onu 1/1/1:15",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 22",
        type: "ZXHN-F670",
        status: "online"
      },
      {
        name: "MAHIRA",
        serialNumber: "ZTEGC454097D",
        oltIndex: "zte gpon-onu 1/1/1:13",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 1100, 200",
        type: "ZXHN-F670",
        status: "online"
      },
      {
        name: "bukmun",
        serialNumber: "ZTEGC453FFB5",
        oltIndex: "zte gpon-onu 1/1/1:9",
        zone: "Zone 1",
        signal: "none",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 21",
        type: "ZXHN-F670",
        status: "offline"
      },
      {
        name: "putri-bukmun",
        serialNumber: "ZTEGC43836E5",
        oltIndex: "zte gpon-onu 1/1/1:8",
        zone: "Zone 1",
        signal: "good",
        bridgeRouter: "R: PPPoE",
        vlan: "1000, 23, 50",
        type: "ZXHN-F670",
        status: "online"
      }
    ];

    // Create sample saved commands
    const sampleCommands = [
      "show running-config",
      "show interface gpon-olt",
      "show gpon onu uncfg",
      "show gpon onu state"
    ];

    // Add sample OLT device for admin user
    const oltDevice: OltDevice = {
      id: this.currentOltDeviceId,
      userId: 1, // Admin user
      name: "ZTE OLT C320",
      ipAddress: "192.168.1.10",
      username: "admin",
      password: "admin123",
      port: 23,
      type: "ZTE",
      location: "Server Room",
      status: "active",
      createdAt: new Date()
    };
    this.oltDevices.set(this.currentOltDeviceId, oltDevice);
    this.currentOltDeviceId++;

    // Add sample ONU devices with OLT reference
    sampleOnus.forEach(onu => {
      const onuDevice: OnuDevice = {
        id: this.currentOnuDeviceId,
        oltDeviceId: 1, // Reference to the OLT we just created
        name: onu.name || "Unknown",
        serialNumber: onu.serialNumber || "Unknown",
        oltIndex: onu.oltIndex || "Unknown",
        zone: onu.zone || null,
        odb: onu.odb || null,
        signal: onu.signal || "none",
        bridgeRouter: onu.bridgeRouter || "B: Bridge",
        vlan: onu.vlan || "1",
        type: onu.type || "Unknown",
        status: onu.status || "offline",
        createdAt: new Date(),
        authDate: null
      };
      this.onuDevices.set(this.currentOnuDeviceId, onuDevice);
      this.currentOnuDeviceId++;
    });
    
    // Add unconfigured ONU devices
    const unconfiguredOnus = [
      {
        serialNumber: "ZTEGC1122334",
        oltIndex: "zte gpon-onu 1/1/2:1",
        type: "ZXHN-F609"
      },
      {
        serialNumber: "ZTEGC9988776",
        oltIndex: "zte gpon-onu 1/1/2:2",
        type: "ZXHN-F670"
      },
      {
        serialNumber: "ZTEGC4455667",
        oltIndex: "zte gpon-onu 1/1/2:3",
        type: "ZXHN-F609"
      }
    ];
    
    unconfiguredOnus.forEach(onu => {
      const onuDevice: OnuDevice = {
        id: this.currentOnuDeviceId,
        oltDeviceId: 1,
        name: "", // Empty name indicates unconfigured
        serialNumber: onu.serialNumber,
        oltIndex: onu.oltIndex,
        zone: null,
        odb: null,
        signal: "good",
        bridgeRouter: null,
        vlan: null,
        type: onu.type,
        status: "unconfigured", // This status indicates an unconfigured ONU
        createdAt: new Date(),
        authDate: null
      };
      this.onuDevices.set(this.currentOnuDeviceId, onuDevice);
      this.currentOnuDeviceId++;
    });

    // Add sample saved commands for admin user
    sampleCommands.forEach((commandText, index) => {
      const savedCommand: SavedCommand = {
        id: this.currentSavedCommandId,
        userId: 1, // Admin user
        name: `Command ${index + 1}`,
        command: commandText,
        description: `Sample command ${index + 1}`,
        createdAt: new Date()
      };
      this.savedCommands.set(this.currentSavedCommandId, savedCommand);
      this.currentSavedCommandId++;
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const registeredAt = new Date();
    const user: User = { ...insertUser, id, registeredAt, lastLogin: registeredAt };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getOltDevices(userId: number): Promise<OltDevice[]> {
    return Array.from(this.oltDevices.values()).filter(
      device => device.userId === userId
    );
  }

  async getOltDevice(id: number): Promise<OltDevice | undefined> {
    return this.oltDevices.get(id);
  }

  async createOltDevice(device: InsertOltDevice): Promise<OltDevice> {
    const id = this.currentOltDeviceId++;
    const createdAt = new Date();
    const oltDevice: OltDevice = { ...device, id, createdAt };
    this.oltDevices.set(id, oltDevice);
    return oltDevice;
  }

  async updateOltDevice(id: number, deviceData: Partial<OltDevice>): Promise<OltDevice | undefined> {
    const device = this.oltDevices.get(id);
    if (!device) return undefined;

    const updatedDevice = { ...device, ...deviceData };
    this.oltDevices.set(id, updatedDevice);
    return updatedDevice;
  }

  async deleteOltDevice(id: number): Promise<boolean> {
    return this.oltDevices.delete(id);
  }

  async getOnuDevices(oltDeviceId?: number): Promise<OnuDevice[]> {
    const devices = Array.from(this.onuDevices.values());
    if (oltDeviceId) {
      return devices.filter(device => device.oltDeviceId === oltDeviceId);
    }
    return devices;
  }

  async getOnuDevice(id: number): Promise<OnuDevice | undefined> {
    return this.onuDevices.get(id);
  }

  async createOnuDevice(device: InsertOnuDevice): Promise<OnuDevice> {
    const id = this.currentOnuDeviceId++;
    const createdAt = new Date();
    const onuDevice: OnuDevice = { ...device, id, createdAt, authDate: null };
    this.onuDevices.set(id, onuDevice);
    return onuDevice;
  }

  async updateOnuDevice(id: number, deviceData: Partial<OnuDevice>): Promise<OnuDevice | undefined> {
    const device = this.onuDevices.get(id);
    if (!device) return undefined;

    const updatedDevice = { ...device, ...deviceData };
    this.onuDevices.set(id, updatedDevice);
    return updatedDevice;
  }

  async deleteOnuDevice(id: number): Promise<boolean> {
    return this.onuDevices.delete(id);
  }

  async getCommandHistory(oltDeviceId: number): Promise<CommandHistory[]> {
    return Array.from(this.commandHistories.values())
      .filter(history => history.oltDeviceId === oltDeviceId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createCommandHistory(history: InsertCommandHistory): Promise<CommandHistory> {
    const id = this.currentCommandHistoryId++;
    const timestamp = new Date();
    const commandHistory: CommandHistory = { ...history, id, timestamp };
    this.commandHistories.set(id, commandHistory);
    return commandHistory;
  }

  async getSavedCommands(userId: number): Promise<SavedCommand[]> {
    return Array.from(this.savedCommands.values())
      .filter(command => command.userId === userId)
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  async createSavedCommand(command: InsertSavedCommand): Promise<SavedCommand> {
    const id = this.currentSavedCommandId++;
    const createdAt = new Date();
    const savedCommand: SavedCommand = { ...command, id, createdAt };
    this.savedCommands.set(id, savedCommand);
    return savedCommand;
  }

  async deleteSavedCommand(id: number): Promise<boolean> {
    return this.savedCommands.delete(id);
  }
}

export const storage = new MemStorage();
