import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { TelnetClient, createTelnetClient } from "./telnet";
import { telnetConnectionSchema } from "@shared/schema";
import { z } from "zod";

const activeConnections: Map<string, TelnetClient> = new Map();

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // OLT Devices routes
  app.get("/api/olt-devices", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const devices = await storage.getOltDevices(req.user.id);
      res.json(devices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch OLT devices" });
    }
  });

  app.post("/api/olt-devices", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.createOltDevice({
        ...req.body,
        userId: req.user.id
      });
      res.status(201).json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to create OLT device" });
    }
  });

  app.get("/api/olt-devices/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.getOltDevice(parseInt(req.params.id));
      if (!device) {
        return res.status(404).json({ message: "OLT device not found" });
      }
      if (device.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch OLT device" });
    }
  });

  // ONU Devices routes
  app.get("/api/onu-devices", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const oltDeviceId = req.query.oltDeviceId 
        ? parseInt(req.query.oltDeviceId as string) 
        : undefined;
      
      const devices = await storage.getOnuDevices(oltDeviceId);
      
      // Filter by status if specified
      const status = req.query.status as string | undefined;
      if (status) {
        const filteredDevices = devices.filter(device => device.status === status);
        return res.json(filteredDevices);
      }
      
      res.json(devices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ONU devices" });
    }
  });
  
  // Get unconfigured ONU devices
  app.get("/api/onu-devices/unconfigured", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const devices = await storage.getOnuDevices();
      const unconfiguredDevices = devices.filter(device => device.status === "unconfigured");
      res.json(unconfiguredDevices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch unconfigured ONU devices" });
    }
  });

  // Get ONU device by ID
  app.get("/api/onu-devices/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const id = parseInt(req.params.id);
      const device = await storage.getOnuDevice(id);
      
      if (!device) {
        return res.status(404).json({ message: "ONU device not found" });
      }
      
      res.json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ONU device" });
    }
  });

  app.post("/api/onu-devices", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const device = await storage.createOnuDevice(req.body);
      res.status(201).json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to create ONU device" });
    }
  });

  // Telnet Communication routes
  app.post("/api/telnet/connect", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const connectionData = telnetConnectionSchema.parse(req.body);
      const { ipAddress, username, password, port } = connectionData;
      
      // Create a unique connection ID for this session
      const connectionId = `${req.user.id}-${ipAddress}-${Date.now()}`;
      
      try {
        const client = await createTelnetClient(ipAddress, port, username, password);
        activeConnections.set(connectionId, client);
        
        res.json({ 
          connectionId,
          status: "connected",
          message: `Connected to ${ipAddress}:${port}`
        });
      } catch (error) {
        res.status(500).json({ 
          status: "error",
          message: `Failed to connect: ${error.message}` 
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          status: "validation_error",
          errors: error.errors 
        });
      }
      res.status(500).json({ 
        status: "error",
        message: "Failed to connect to OLT device" 
      });
    }
  });

  app.post("/api/telnet/execute", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const { connectionId, command } = req.body;
      
      if (!connectionId || !command) {
        return res.status(400).json({ 
          status: "error",
          message: "connectionId and command are required" 
        });
      }
      
      const client = activeConnections.get(connectionId);
      if (!client) {
        return res.status(404).json({ 
          status: "error",
          message: "Connection not found or expired" 
        });
      }
      
      try {
        const response = await client.execute(command);
        
        // Save command history if an OLT device ID is provided
        if (req.body.oltDeviceId) {
          await storage.createCommandHistory({
            command,
            response,
            status: "success",
            oltDeviceId: req.body.oltDeviceId,
            userId: req.user.id
          });
        }
        
        res.json({ 
          status: "success",
          command,
          response
        });
      } catch (error) {
        if (req.body.oltDeviceId) {
          await storage.createCommandHistory({
            command,
            response: error.message,
            status: "error",
            oltDeviceId: req.body.oltDeviceId,
            userId: req.user.id
          });
        }
        
        res.status(500).json({ 
          status: "error",
          message: `Command execution failed: ${error.message}` 
        });
      }
    } catch (error) {
      res.status(500).json({ 
        status: "error",
        message: "Failed to execute command" 
      });
    }
  });

  app.post("/api/telnet/disconnect", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const { connectionId } = req.body;
      
      if (!connectionId) {
        return res.status(400).json({ 
          status: "error",
          message: "connectionId is required" 
        });
      }
      
      const client = activeConnections.get(connectionId);
      if (!client) {
        return res.status(404).json({ 
          status: "error",
          message: "Connection not found or already closed" 
        });
      }
      
      await client.end();
      activeConnections.delete(connectionId);
      
      res.json({ 
        status: "success",
        message: "Disconnected successfully" 
      });
    } catch (error) {
      res.status(500).json({ 
        status: "error",
        message: "Failed to disconnect" 
      });
    }
  });

  // Command History routes
  app.get("/api/command-history/:oltDeviceId", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const oltDeviceId = parseInt(req.params.oltDeviceId);
      const history = await storage.getCommandHistory(oltDeviceId);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch command history" });
    }
  });

  // Saved Commands routes
  app.get("/api/saved-commands", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const commands = await storage.getSavedCommands(req.user.id);
      res.json(commands);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch saved commands" });
    }
  });

  app.post("/api/saved-commands", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const command = await storage.createSavedCommand({
        ...req.body,
        userId: req.user.id
      });
      res.status(201).json(command);
    } catch (error) {
      res.status(500).json({ message: "Failed to save command" });
    }
  });

  app.delete("/api/saved-commands/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const success = await storage.deleteSavedCommand(parseInt(req.params.id));
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "Command not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to delete command" });
    }
  });

  // User profile update
  app.patch("/api/user", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const { password, ...updateData } = req.body;
      const updatedUser = await storage.updateUser(req.user.id, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove sensitive data before returning
      const { password: _, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user profile" });
    }
  });

  // Clean up connections when server is shutting down
  process.on('SIGINT', async () => {
    console.log('Closing all telnet connections...');
    for (const [id, client] of activeConnections.entries()) {
      try {
        await client.end();
        console.log(`Closed connection ${id}`);
      } catch (error) {
        console.error(`Error closing connection ${id}:`, error);
      }
    }
    activeConnections.clear();
    process.exit(0);
  });

  const httpServer = createServer(app);
  return httpServer;
}
