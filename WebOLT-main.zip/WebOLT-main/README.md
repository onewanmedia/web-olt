# WebOLT - Network Management System

WebOLT adalah sistem manajemen jaringan berbasis web untuk perangkat OLT ZTE dan non-ZTE. Aplikasi ini menyediakan antarmuka yang responsif dan terinspirasi dari sistem manajemen OLT NetNumen, dengan dukungan untuk perangkat desktop dan mobile.

![WebOLT Dashboard](https://github.com/ardani17/WebOLT/raw/main/dashboard-preview.png)

## Fitur Utama

- **Manajemen Perangkat OLT**: Pantau dan kelola perangkat OLT ZTE dan non-ZTE
- **Pelacakan Konfigurasi ONU**: Lihat dan atur konfigurasi perangkat ONU
- **Monitoring Trafik Uplink**: Visualisasi trafik jaringan secara real-time
- **Pengelolaan Akses Multi-Peran**: Sistem manajemen pengguna berbasis peran
- **Penagihan dan Langganan**: Kelola layanan langganan bulanan
- **Antarmuka Responsif**: Tampilan yang optimal baik untuk desktop maupun mobile
- **Registrasi ONU Baru**: Alur kerja untuk mendaftarkan ONU baru

## Teknologi yang Digunakan

### Frontend
- **React 18**: Library JavaScript untuk membangun antarmuka pengguna
- **TypeScript**: Bahasa pemrograman yang memberikan static typing di atas JavaScript
- **Tailwind CSS**: Framework CSS untuk desain yang cepat dan efisien
- **Shadcn/ui**: Komponen UI yang dapat digunakan kembali dan sangat dapat disesuaikan
- **Recharts**: Library chart yang dibangun di atas D3.js untuk visualisasi data
- **React Query**: Library untuk manajemen state server dan caching data
- **React Hook Form**: Library untuk validasi dan penanganan form efisien
- **Wouter**: Router yang ringan untuk aplikasi React

### Backend
- **Node.js**: Runtime JavaScript untuk server
- **Express**: Framework web untuk Node.js
- **Drizzle ORM**: ORM TypeScript yang ringan dan type-safe
- **PostgreSQL**: Sistem manajemen basis data relasional
- **Passport.js**: Middleware autentikasi untuk Node.js
- **Net Module**: Modul Node.js untuk protokol Telnet
- **Zod**: Library validasi schema TypeScript

## Cara Instalasi

### Opsi 1: Menggunakan Docker (Direkomendasikan)

#### Prasyarat
- Docker dan Docker Compose

#### Langkah Instalasi (Cara Cepat)

1. **Clone Repository**
   ```bash
   git clone https://github.com/ardani17/WebOLT.git
   cd WebOLT
   ```

2. **Jalankan Script Inisialisasi**
   ```bash
   ./init.sh
   ```
   
   Script ini akan secara otomatis:
   - Membuat file `.env` dari `.env.example`
   - Membangun dan menjalankan container Docker
   - Menampilkan informasi akses aplikasi
   
   Aplikasi akan berjalan di `http://localhost:5000`

#### Langkah Instalasi (Manual)

1. **Clone Repository**
   ```bash
   git clone https://github.com/ardani17/WebOLT.git
   cd WebOLT
   ```

2. **Konfigurasi Lingkungan**
   ```bash
   cp .env.example .env
   ```
   
   Anda bisa menyesuaikan nilai dalam file `.env` sesuai kebutuhan.

3. **Membangun dan Menjalankan Aplikasi dengan Docker Compose**
   ```bash
   docker-compose up -d
   ```
   
   Perintah ini akan membangun container aplikasi, menjalankan database PostgreSQL, dan menghubungkan keduanya.
   
   Aplikasi akan berjalan di `http://localhost:5000`

4. **Menghentikan Aplikasi**
   ```bash
   docker-compose down
   ```

### Opsi 2: Instalasi Manual

#### Prasyarat
- Node.js (versi 18 atau lebih baru)
- PostgreSQL (versi 14 atau lebih baru)
- npm atau yarn

#### Langkah Instalasi

1. **Clone Repository**
   ```bash
   git clone https://github.com/ardani17/WebOLT.git
   cd WebOLT
   ```

2. **Instalasi Dependency**
   ```bash
   npm install
   ```

3. **Konfigurasi Database**
   - Buat database PostgreSQL baru
   - Salin file `.env.example` menjadi `.env`
   - Atur variabel lingkungan untuk koneksi database di file `.env`:
     ```
     DATABASE_URL=postgresql://username:password@localhost:5432/webolt
     ```

4. **Migrasi Database**
   ```bash
   npm run db:push
   ```

5. **Menjalankan Aplikasi (Development)**
   ```bash
   npm run dev
   ```
   Aplikasi akan berjalan di `http://localhost:3000`

6. **Build untuk Produksi**
   ```bash
   npm run build
   ```

7. **Menjalankan Aplikasi (Produksi)**
   ```bash
   npm start
   ```

## Petunjuk Penggunaan

1. Login dengan kredensial admin default (username: admin, password: admin123)
2. Gunakan menu navigasi untuk mengakses berbagai fitur
3. Tambahkan perangkat OLT untuk memulai monitoring jaringan
4. Daftarkan perangkat ONU dan konfigurasikan sesuai kebutuhan
5. Pantau trafik dan status perangkat melalui dashboard

## Struktur Proyek

Proyek ini mengikuti struktur direktori berikut:

### Direktori Utama
- `server/` - Berisi semua kode backend (routes, auth, storage, telnet)
- `client/` - Berisi semua kode frontend (components, pages, hooks, lib)
- `shared/` - Berisi schema dan tipe yang digunakan bersama oleh frontend dan backend

```
WebOLT/
├── client/                    # Kode frontend
│   ├── src/
│   │   ├── components/        # Komponen React
│   │   ├── hooks/             # Custom React hooks
│   │   ├── lib/               # Utility dan helper
│   │   ├── pages/             # Halaman aplikasi
│   │   └── App.tsx, main.tsx  # Main entry files
├── server/                    # Kode backend
│   ├── auth.ts                # Konfigurasi autentikasi
│   ├── routes.ts              # Definisi API routes
│   ├── storage.ts             # Abstraksi penyimpanan data
│   ├── telnet.ts              # Implementasi client Telnet
│   ├── index.ts               # Entry point aplikasi
│   └── vite.ts                # Konfigurasi vite untuk backend
├── shared/                    # Kode yang digunakan frontend & backend
│   ├── schema.ts              # Skema database dan validasi
├── Dockerfile                 # Konfigurasi untuk membangun container Docker
├── docker-compose.yml         # Konfigurasi layanan kontainer (app dan database)
├── init.sh                    # Script inisialisasi untuk mempermudah setup Docker
├── .env.example               # Contoh konfigurasi variabel lingkungan
├── package.json               # Dependensi dan scripts
└── ...
```

## Kontribusi
Kontribusi selalu diterima, silakan buat pull request atau laporkan masalah yang ditemukan.

## Info Pengembangan

Proyek ini dikembangkan dengan fokus pada keandalan, keamanan, dan kemudahan penggunaan untuk pengelolaan jaringan berbasis OLT. Untuk informasi lebih lanjut atau dukungan, silakan hubungi tim pengembang.
