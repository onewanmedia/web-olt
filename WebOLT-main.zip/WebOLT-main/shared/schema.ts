import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email"),
  registeredAt: timestamp("registered_at").defaultNow(),
  lastLogin: timestamp("last_login"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
});

// OLT model
export const oltDevices = pgTable("olt_devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ipAddress: text("ip_address").notNull(),
  username: text("username").notNull(),
  password: text("password").notNull(),
  port: integer("port").default(23),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOltDeviceSchema = createInsertSchema(oltDevices).pick({
  name: true,
  ipAddress: true,
  username: true,
  password: true,
  port: true,
  userId: true,
});

// ONU model
export const onuDevices = pgTable("onu_devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serialNumber: text("serial_number").notNull(),
  oltIndex: text("olt_index").notNull(), // e.g., 1/1/1:19
  zone: text("zone"),
  odb: text("odb"),
  signal: text("signal"),
  bridgeRouter: text("bridge_router"),
  vlan: text("vlan"),
  type: text("type"),
  status: text("status").default("offline"),
  oltDeviceId: integer("olt_device_id").references(() => oltDevices.id),
  createdAt: timestamp("created_at").defaultNow(),
  authDate: timestamp("auth_date"),
});

export const insertOnuDeviceSchema = createInsertSchema(onuDevices).omit({
  id: true,
  createdAt: true,
  authDate: true,
});

// Command history model
export const commandHistory = pgTable("command_history", {
  id: serial("id").primaryKey(),
  command: text("command").notNull(),
  response: text("response"),
  status: text("status").default("pending"),
  timestamp: timestamp("timestamp").defaultNow(),
  oltDeviceId: integer("olt_device_id").references(() => oltDevices.id),
  userId: integer("user_id").references(() => users.id),
});

export const insertCommandHistorySchema = createInsertSchema(commandHistory).pick({
  command: true,
  response: true,
  status: true,
  oltDeviceId: true,
  userId: true,
});

// Saved commands model
export const savedCommands = pgTable("saved_commands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  command: text("command").notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSavedCommandSchema = createInsertSchema(savedCommands).pick({
  name: true,
  command: true,
  userId: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertOltDevice = z.infer<typeof insertOltDeviceSchema>;
export type OltDevice = typeof oltDevices.$inferSelect;

export type InsertOnuDevice = z.infer<typeof insertOnuDeviceSchema>;
export type OnuDevice = typeof onuDevices.$inferSelect;

export type InsertCommandHistory = z.infer<typeof insertCommandHistorySchema>;
export type CommandHistory = typeof commandHistory.$inferSelect;

export type InsertSavedCommand = z.infer<typeof insertSavedCommandSchema>;
export type SavedCommand = typeof savedCommands.$inferSelect;

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginCredentials = z.infer<typeof loginSchema>;

// Telnet connection schema
export const telnetConnectionSchema = z.object({
  ipAddress: z.string().min(1, "IP Address is required"),
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
  port: z.number().default(23),
});

export type TelnetConnection = z.infer<typeof telnetConnectionSchema>;
